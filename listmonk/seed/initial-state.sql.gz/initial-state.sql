--
-- PostgreSQL database dump
--



-- Dumped from database version 17.9
-- Dumped by pg_dump version 17.9

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_user_role_id_fkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_list_role_id_fkey;
ALTER TABLE IF EXISTS ONLY public.subscriber_lists DROP CONSTRAINT IF EXISTS subscriber_lists_subscriber_id_fkey;
ALTER TABLE IF EXISTS ONLY public.subscriber_lists DROP CONSTRAINT IF EXISTS subscriber_lists_list_id_fkey;
ALTER TABLE IF EXISTS ONLY public.roles DROP CONSTRAINT IF EXISTS roles_parent_id_fkey;
ALTER TABLE IF EXISTS ONLY public.roles DROP CONSTRAINT IF EXISTS roles_list_id_fkey;
ALTER TABLE IF EXISTS ONLY public.link_clicks DROP CONSTRAINT IF EXISTS link_clicks_subscriber_id_fkey;
ALTER TABLE IF EXISTS ONLY public.link_clicks DROP CONSTRAINT IF EXISTS link_clicks_link_id_fkey;
ALTER TABLE IF EXISTS ONLY public.link_clicks DROP CONSTRAINT IF EXISTS link_clicks_campaign_id_fkey;
ALTER TABLE IF EXISTS ONLY public.campaigns DROP CONSTRAINT IF EXISTS campaigns_template_id_fkey;
ALTER TABLE IF EXISTS ONLY public.campaigns DROP CONSTRAINT IF EXISTS campaigns_archive_template_id_fkey;
ALTER TABLE IF EXISTS ONLY public.campaign_views DROP CONSTRAINT IF EXISTS campaign_views_subscriber_id_fkey;
ALTER TABLE IF EXISTS ONLY public.campaign_views DROP CONSTRAINT IF EXISTS campaign_views_campaign_id_fkey;
ALTER TABLE IF EXISTS ONLY public.campaign_media DROP CONSTRAINT IF EXISTS campaign_media_media_id_fkey;
ALTER TABLE IF EXISTS ONLY public.campaign_media DROP CONSTRAINT IF EXISTS campaign_media_campaign_id_fkey;
ALTER TABLE IF EXISTS ONLY public.campaign_lists DROP CONSTRAINT IF EXISTS campaign_lists_list_id_fkey;
ALTER TABLE IF EXISTS ONLY public.campaign_lists DROP CONSTRAINT IF EXISTS campaign_lists_campaign_id_fkey;
ALTER TABLE IF EXISTS ONLY public.bounces DROP CONSTRAINT IF EXISTS bounces_subscriber_id_fkey;
ALTER TABLE IF EXISTS ONLY public.bounces DROP CONSTRAINT IF EXISTS bounces_campaign_id_fkey;
DROP INDEX IF EXISTS public.templates_is_default_idx;
DROP INDEX IF EXISTS public.mat_list_subscriber_stats_idx;
DROP INDEX IF EXISTS public.mat_dashboard_stats_idx;
DROP INDEX IF EXISTS public.mat_dashboard_charts_idx;
DROP INDEX IF EXISTS public.idx_views_subscriber_id;
DROP INDEX IF EXISTS public.idx_views_date;
DROP INDEX IF EXISTS public.idx_views_camp_id;
DROP INDEX IF EXISTS public.idx_subs_updated_at;
DROP INDEX IF EXISTS public.idx_subs_status;
DROP INDEX IF EXISTS public.idx_subs_id_status;
DROP INDEX IF EXISTS public.idx_subs_email;
DROP INDEX IF EXISTS public.idx_subs_created_at;
DROP INDEX IF EXISTS public.idx_sub_lists_sub_id;
DROP INDEX IF EXISTS public.idx_sub_lists_status;
DROP INDEX IF EXISTS public.idx_sub_lists_list_id;
DROP INDEX IF EXISTS public.idx_settings_key;
DROP INDEX IF EXISTS public.idx_sessions;
DROP INDEX IF EXISTS public.idx_roles_name;
DROP INDEX IF EXISTS public.idx_roles;
DROP INDEX IF EXISTS public.idx_media_filename;
DROP INDEX IF EXISTS public.idx_lists_updated_at;
DROP INDEX IF EXISTS public.idx_lists_type;
DROP INDEX IF EXISTS public.idx_lists_status;
DROP INDEX IF EXISTS public.idx_lists_optin;
DROP INDEX IF EXISTS public.idx_lists_name;
DROP INDEX IF EXISTS public.idx_lists_created_at;
DROP INDEX IF EXISTS public.idx_clicks_sub_id;
DROP INDEX IF EXISTS public.idx_clicks_link_id;
DROP INDEX IF EXISTS public.idx_clicks_date;
DROP INDEX IF EXISTS public.idx_clicks_camp_id;
DROP INDEX IF EXISTS public.idx_camps_updated_at;
DROP INDEX IF EXISTS public.idx_camps_status;
DROP INDEX IF EXISTS public.idx_camps_name;
DROP INDEX IF EXISTS public.idx_camps_created_at;
DROP INDEX IF EXISTS public.idx_camp_media_id;
DROP INDEX IF EXISTS public.idx_camp_media_camp_id;
DROP INDEX IF EXISTS public.idx_camp_lists_list_id;
DROP INDEX IF EXISTS public.idx_camp_lists_camp_id;
DROP INDEX IF EXISTS public.idx_bounces_sub_id;
DROP INDEX IF EXISTS public.idx_bounces_source;
DROP INDEX IF EXISTS public.idx_bounces_date;
DROP INDEX IF EXISTS public.idx_bounces_camp_id;
DROP INDEX IF EXISTS public.campaign_lists_campaign_id_list_id_idx;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_username_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.templates DROP CONSTRAINT IF EXISTS templates_pkey;
ALTER TABLE IF EXISTS ONLY public.subscribers DROP CONSTRAINT IF EXISTS subscribers_uuid_key;
ALTER TABLE IF EXISTS ONLY public.subscribers DROP CONSTRAINT IF EXISTS subscribers_pkey;
ALTER TABLE IF EXISTS ONLY public.subscribers DROP CONSTRAINT IF EXISTS subscribers_email_key;
ALTER TABLE IF EXISTS ONLY public.subscriber_lists DROP CONSTRAINT IF EXISTS subscriber_lists_pkey;
ALTER TABLE IF EXISTS ONLY public.settings DROP CONSTRAINT IF EXISTS settings_key_key;
ALTER TABLE IF EXISTS ONLY public.sessions DROP CONSTRAINT IF EXISTS sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.roles DROP CONSTRAINT IF EXISTS roles_pkey;
ALTER TABLE IF EXISTS ONLY public.media DROP CONSTRAINT IF EXISTS media_uuid_key;
ALTER TABLE IF EXISTS ONLY public.media DROP CONSTRAINT IF EXISTS media_pkey;
ALTER TABLE IF EXISTS ONLY public.lists DROP CONSTRAINT IF EXISTS lists_uuid_key;
ALTER TABLE IF EXISTS ONLY public.lists DROP CONSTRAINT IF EXISTS lists_pkey;
ALTER TABLE IF EXISTS ONLY public.links DROP CONSTRAINT IF EXISTS links_uuid_key;
ALTER TABLE IF EXISTS ONLY public.links DROP CONSTRAINT IF EXISTS links_url_key;
ALTER TABLE IF EXISTS ONLY public.links DROP CONSTRAINT IF EXISTS links_pkey;
ALTER TABLE IF EXISTS ONLY public.link_clicks DROP CONSTRAINT IF EXISTS link_clicks_pkey;
ALTER TABLE IF EXISTS ONLY public.campaigns DROP CONSTRAINT IF EXISTS campaigns_uuid_key;
ALTER TABLE IF EXISTS ONLY public.campaigns DROP CONSTRAINT IF EXISTS campaigns_pkey;
ALTER TABLE IF EXISTS ONLY public.campaigns DROP CONSTRAINT IF EXISTS campaigns_archive_slug_key;
ALTER TABLE IF EXISTS ONLY public.campaign_views DROP CONSTRAINT IF EXISTS campaign_views_pkey;
ALTER TABLE IF EXISTS ONLY public.campaign_lists DROP CONSTRAINT IF EXISTS campaign_lists_pkey;
ALTER TABLE IF EXISTS ONLY public.bounces DROP CONSTRAINT IF EXISTS bounces_pkey;
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.templates ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.subscribers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.roles ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.media ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.lists ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.links ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.link_clicks ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.campaigns ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.campaign_views ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.campaign_lists ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.bounces ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.users_id_seq;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public.templates_id_seq;
DROP TABLE IF EXISTS public.templates;
DROP SEQUENCE IF EXISTS public.subscribers_id_seq;
DROP TABLE IF EXISTS public.settings;
DROP TABLE IF EXISTS public.sessions;
DROP SEQUENCE IF EXISTS public.roles_id_seq;
DROP TABLE IF EXISTS public.roles;
DROP SEQUENCE IF EXISTS public.media_id_seq;
DROP TABLE IF EXISTS public.media;
DROP MATERIALIZED VIEW IF EXISTS public.mat_list_subscriber_stats;
DROP MATERIALIZED VIEW IF EXISTS public.mat_dashboard_counts;
DROP TABLE IF EXISTS public.subscribers;
DROP TABLE IF EXISTS public.subscriber_lists;
DROP MATERIALIZED VIEW IF EXISTS public.mat_dashboard_charts;
DROP SEQUENCE IF EXISTS public.lists_id_seq;
DROP TABLE IF EXISTS public.lists;
DROP SEQUENCE IF EXISTS public.links_id_seq;
DROP TABLE IF EXISTS public.links;
DROP SEQUENCE IF EXISTS public.link_clicks_id_seq;
DROP TABLE IF EXISTS public.link_clicks;
DROP SEQUENCE IF EXISTS public.campaigns_id_seq;
DROP TABLE IF EXISTS public.campaigns;
DROP SEQUENCE IF EXISTS public.campaign_views_id_seq;
DROP TABLE IF EXISTS public.campaign_views;
DROP TABLE IF EXISTS public.campaign_media;
DROP SEQUENCE IF EXISTS public.campaign_lists_id_seq;
DROP TABLE IF EXISTS public.campaign_lists;
DROP SEQUENCE IF EXISTS public.bounces_id_seq;
DROP TABLE IF EXISTS public.bounces;
DROP TYPE IF EXISTS public.user_type;
DROP TYPE IF EXISTS public.user_status;
DROP TYPE IF EXISTS public.twofa_type;
DROP TYPE IF EXISTS public.template_type;
DROP TYPE IF EXISTS public.subscription_status;
DROP TYPE IF EXISTS public.subscriber_status;
DROP TYPE IF EXISTS public.role_type;
DROP TYPE IF EXISTS public.list_type;
DROP TYPE IF EXISTS public.list_status;
DROP TYPE IF EXISTS public.list_optin;
DROP TYPE IF EXISTS public.content_type;
DROP TYPE IF EXISTS public.campaign_type;
DROP TYPE IF EXISTS public.campaign_status;
DROP TYPE IF EXISTS public.bounce_type;
DROP EXTENSION IF EXISTS pgcrypto;
--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: bounce_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.bounce_type AS ENUM (
    'soft',
    'hard',
    'complaint'
);


--
-- Name: campaign_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.campaign_status AS ENUM (
    'draft',
    'running',
    'scheduled',
    'paused',
    'cancelled',
    'finished'
);


--
-- Name: campaign_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.campaign_type AS ENUM (
    'regular',
    'optin'
);


--
-- Name: content_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.content_type AS ENUM (
    'richtext',
    'html',
    'plain',
    'markdown',
    'visual'
);


--
-- Name: list_optin; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.list_optin AS ENUM (
    'single',
    'double'
);


--
-- Name: list_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.list_status AS ENUM (
    'active',
    'archived'
);


--
-- Name: list_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.list_type AS ENUM (
    'public',
    'private',
    'temporary'
);


--
-- Name: role_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.role_type AS ENUM (
    'user',
    'list'
);


--
-- Name: subscriber_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.subscriber_status AS ENUM (
    'enabled',
    'disabled',
    'blocklisted'
);


--
-- Name: subscription_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.subscription_status AS ENUM (
    'unconfirmed',
    'confirmed',
    'unsubscribed'
);


--
-- Name: template_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.template_type AS ENUM (
    'campaign',
    'campaign_visual',
    'tx'
);


--
-- Name: twofa_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.twofa_type AS ENUM (
    'none',
    'totp'
);


--
-- Name: user_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.user_status AS ENUM (
    'enabled',
    'disabled'
);


--
-- Name: user_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.user_type AS ENUM (
    'user',
    'api'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bounces; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bounces (
    id integer NOT NULL,
    subscriber_id integer NOT NULL,
    campaign_id integer,
    type public.bounce_type DEFAULT 'hard'::public.bounce_type NOT NULL,
    source text DEFAULT ''::text NOT NULL,
    meta jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: bounces_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bounces_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bounces_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bounces_id_seq OWNED BY public.bounces.id;


--
-- Name: campaign_lists; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.campaign_lists (
    id bigint NOT NULL,
    campaign_id integer NOT NULL,
    list_id integer,
    list_name text DEFAULT ''::text NOT NULL
);


--
-- Name: campaign_lists_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.campaign_lists_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: campaign_lists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.campaign_lists_id_seq OWNED BY public.campaign_lists.id;


--
-- Name: campaign_media; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.campaign_media (
    campaign_id integer,
    media_id integer,
    filename text DEFAULT ''::text NOT NULL
);


--
-- Name: campaign_views; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.campaign_views (
    id bigint NOT NULL,
    campaign_id integer NOT NULL,
    subscriber_id integer,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: campaign_views_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.campaign_views_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: campaign_views_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.campaign_views_id_seq OWNED BY public.campaign_views.id;


--
-- Name: campaigns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.campaigns (
    id integer NOT NULL,
    uuid uuid NOT NULL,
    name text NOT NULL,
    subject text NOT NULL,
    from_email text NOT NULL,
    body text NOT NULL,
    body_source text,
    altbody text,
    content_type public.content_type DEFAULT 'richtext'::public.content_type NOT NULL,
    send_at timestamp with time zone,
    headers jsonb DEFAULT '[]'::jsonb NOT NULL,
    attribs jsonb DEFAULT '{}'::jsonb NOT NULL,
    status public.campaign_status DEFAULT 'draft'::public.campaign_status NOT NULL,
    tags character varying(100)[],
    type public.campaign_type DEFAULT 'regular'::public.campaign_type,
    messenger text NOT NULL,
    template_id integer,
    to_send integer DEFAULT 0 NOT NULL,
    sent integer DEFAULT 0 NOT NULL,
    max_subscriber_id integer DEFAULT 0 NOT NULL,
    last_subscriber_id integer DEFAULT 0 NOT NULL,
    archive boolean DEFAULT false NOT NULL,
    archive_slug text,
    archive_template_id integer,
    archive_meta jsonb DEFAULT '{}'::jsonb NOT NULL,
    started_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: campaigns_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.campaigns_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: campaigns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.campaigns_id_seq OWNED BY public.campaigns.id;


--
-- Name: link_clicks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.link_clicks (
    id bigint NOT NULL,
    campaign_id integer,
    link_id integer NOT NULL,
    subscriber_id integer,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: link_clicks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.link_clicks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: link_clicks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.link_clicks_id_seq OWNED BY public.link_clicks.id;


--
-- Name: links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.links (
    id integer NOT NULL,
    uuid uuid NOT NULL,
    url text NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: links_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.links_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.links_id_seq OWNED BY public.links.id;


--
-- Name: lists; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lists (
    id integer NOT NULL,
    uuid uuid NOT NULL,
    name text NOT NULL,
    type public.list_type NOT NULL,
    optin public.list_optin DEFAULT 'single'::public.list_optin NOT NULL,
    status public.list_status DEFAULT 'active'::public.list_status NOT NULL,
    tags character varying(100)[],
    description text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: lists_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.lists_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: lists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.lists_id_seq OWNED BY public.lists.id;


--
-- Name: mat_dashboard_charts; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.mat_dashboard_charts AS
 WITH clicks AS (
         SELECT json_agg(row_to_json("row".*)) AS json_agg
           FROM ( WITH viewdates AS (
                         SELECT (link_clicks_1.created_at)::date AS to_date,
                            ((link_clicks_1.created_at)::date - '30 days'::interval) AS from_date
                           FROM public.link_clicks link_clicks_1
                          ORDER BY link_clicks_1.id DESC
                         LIMIT 1
                        )
                 SELECT count(*) AS count,
                    (link_clicks.created_at)::date AS date
                   FROM public.link_clicks
                  WHERE ((link_clicks.created_at >= ( SELECT viewdates.from_date
                           FROM viewdates)) AND (link_clicks.created_at < (( SELECT viewdates.to_date
                           FROM viewdates) + '1 day'::interval)))
                  GROUP BY ((link_clicks.created_at)::date)
                  ORDER BY ((link_clicks.created_at)::date)) "row"
        ), views AS (
         SELECT json_agg(row_to_json("row".*)) AS json_agg
           FROM ( WITH viewdates AS (
                         SELECT (campaign_views_1.created_at)::date AS to_date,
                            ((campaign_views_1.created_at)::date - '30 days'::interval) AS from_date
                           FROM public.campaign_views campaign_views_1
                          ORDER BY campaign_views_1.id DESC
                         LIMIT 1
                        )
                 SELECT count(*) AS count,
                    (campaign_views.created_at)::date AS date
                   FROM public.campaign_views
                  WHERE ((campaign_views.created_at >= ( SELECT viewdates.from_date
                           FROM viewdates)) AND (campaign_views.created_at < (( SELECT viewdates.to_date
                           FROM viewdates) + '1 day'::interval)))
                  GROUP BY ((campaign_views.created_at)::date)
                  ORDER BY ((campaign_views.created_at)::date)) "row"
        )
 SELECT now() AS updated_at,
    json_build_object('link_clicks', COALESCE(( SELECT clicks.json_agg
           FROM clicks), '[]'::json), 'campaign_views', COALESCE(( SELECT views.json_agg
           FROM views), '[]'::json)) AS data
  WITH NO DATA;


--
-- Name: subscriber_lists; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscriber_lists (
    subscriber_id integer NOT NULL,
    list_id integer NOT NULL,
    meta jsonb DEFAULT '{}'::jsonb NOT NULL,
    status public.subscription_status DEFAULT 'unconfirmed'::public.subscription_status NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: subscribers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscribers (
    id integer NOT NULL,
    uuid uuid NOT NULL,
    email text NOT NULL,
    name text NOT NULL,
    attribs jsonb DEFAULT '{}'::jsonb NOT NULL,
    status public.subscriber_status DEFAULT 'enabled'::public.subscriber_status NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: mat_dashboard_counts; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.mat_dashboard_counts AS
 WITH subs AS (
         SELECT count(*) AS num,
            subscribers.status
           FROM public.subscribers
          GROUP BY subscribers.status
        )
 SELECT now() AS updated_at,
    json_build_object('subscribers', json_build_object('total', ( SELECT sum(subs.num) AS sum
           FROM subs), 'blocklisted', ( SELECT subs.num
           FROM subs
          WHERE (subs.status = 'blocklisted'::public.subscriber_status)), 'orphans', ( SELECT count(subscribers.id) AS count
           FROM (public.subscribers
             LEFT JOIN public.subscriber_lists ON ((subscribers.id = subscriber_lists.subscriber_id)))
          WHERE (subscriber_lists.subscriber_id IS NULL))), 'lists', json_build_object('total', ( SELECT count(*) AS count
           FROM public.lists), 'private', ( SELECT count(*) AS count
           FROM public.lists
          WHERE (lists.type = 'private'::public.list_type)), 'public', ( SELECT count(*) AS count
           FROM public.lists
          WHERE (lists.type = 'public'::public.list_type)), 'optin_single', ( SELECT count(*) AS count
           FROM public.lists
          WHERE (lists.optin = 'single'::public.list_optin)), 'optin_double', ( SELECT count(*) AS count
           FROM public.lists
          WHERE (lists.optin = 'double'::public.list_optin))), 'campaigns', json_build_object('total', ( SELECT count(*) AS count
           FROM public.campaigns), 'by_status', ( SELECT json_object_agg(r.status, r.num) AS json_object_agg
           FROM ( SELECT campaigns.status,
                    count(*) AS num
                   FROM public.campaigns
                  GROUP BY campaigns.status) r)), 'messages', ( SELECT sum(campaigns.sent) AS messages
           FROM public.campaigns)) AS data
  WITH NO DATA;


--
-- Name: mat_list_subscriber_stats; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.mat_list_subscriber_stats AS
 SELECT now() AS updated_at,
    lists.id AS list_id,
    subscriber_lists.status,
    count(subscriber_lists.status) AS subscriber_count
   FROM (public.lists
     LEFT JOIN public.subscriber_lists ON ((subscriber_lists.list_id = lists.id)))
  GROUP BY lists.id, subscriber_lists.status
UNION ALL
 SELECT now() AS updated_at,
    0 AS list_id,
    NULL::public.subscription_status AS status,
    count(subscribers.id) AS subscriber_count
   FROM public.subscribers
  WITH NO DATA;


--
-- Name: media; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.media (
    id integer NOT NULL,
    uuid uuid NOT NULL,
    provider text DEFAULT ''::text NOT NULL,
    filename text NOT NULL,
    content_type text DEFAULT 'application/octet-stream'::text NOT NULL,
    thumb text NOT NULL,
    meta jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: media_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.media_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: media_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.media_id_seq OWNED BY public.media.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    type public.role_type DEFAULT 'user'::public.role_type NOT NULL,
    parent_id integer,
    list_id integer,
    permissions text[] DEFAULT '{}'::text[] NOT NULL,
    name text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    id text NOT NULL,
    data jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.settings (
    key text NOT NULL,
    value jsonb DEFAULT '{}'::jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: subscribers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.subscribers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: subscribers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.subscribers_id_seq OWNED BY public.subscribers.id;


--
-- Name: templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.templates (
    id integer NOT NULL,
    name text NOT NULL,
    type public.template_type DEFAULT 'campaign'::public.template_type NOT NULL,
    subject text NOT NULL,
    body text NOT NULL,
    body_source text,
    is_default boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.templates_id_seq OWNED BY public.templates.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username text NOT NULL,
    password_login boolean DEFAULT false NOT NULL,
    password text,
    email text NOT NULL,
    name text NOT NULL,
    avatar text,
    type public.user_type DEFAULT 'user'::public.user_type NOT NULL,
    user_role_id integer NOT NULL,
    list_role_id integer,
    status public.user_status DEFAULT 'disabled'::public.user_status NOT NULL,
    twofa_type public.twofa_type DEFAULT 'none'::public.twofa_type NOT NULL,
    twofa_key text,
    loggedin_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: bounces id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bounces ALTER COLUMN id SET DEFAULT nextval('public.bounces_id_seq'::regclass);


--
-- Name: campaign_lists id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaign_lists ALTER COLUMN id SET DEFAULT nextval('public.campaign_lists_id_seq'::regclass);


--
-- Name: campaign_views id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaign_views ALTER COLUMN id SET DEFAULT nextval('public.campaign_views_id_seq'::regclass);


--
-- Name: campaigns id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaigns ALTER COLUMN id SET DEFAULT nextval('public.campaigns_id_seq'::regclass);


--
-- Name: link_clicks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.link_clicks ALTER COLUMN id SET DEFAULT nextval('public.link_clicks_id_seq'::regclass);


--
-- Name: links id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.links ALTER COLUMN id SET DEFAULT nextval('public.links_id_seq'::regclass);


--
-- Name: lists id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lists ALTER COLUMN id SET DEFAULT nextval('public.lists_id_seq'::regclass);


--
-- Name: media id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.media ALTER COLUMN id SET DEFAULT nextval('public.media_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: subscribers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscribers ALTER COLUMN id SET DEFAULT nextval('public.subscribers_id_seq'::regclass);


--
-- Name: templates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.templates ALTER COLUMN id SET DEFAULT nextval('public.templates_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: bounces; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bounces (id, subscriber_id, campaign_id, type, source, meta, created_at) FROM stdin;
\.


--
-- Data for Name: campaign_lists; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.campaign_lists (id, campaign_id, list_id, list_name) FROM stdin;
51	49	39	Partners & Press
49	49	35	Newsletter
50	49	36	Community / Members
60	52	35	Newsletter
\.


--
-- Data for Name: campaign_media; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.campaign_media (campaign_id, media_id, filename) FROM stdin;
\.


--
-- Data for Name: campaign_views; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.campaign_views (id, campaign_id, subscriber_id, created_at) FROM stdin;
15	49	\N	2026-04-20 04:51:15.964334+00
17	49	\N	2026-04-20 04:51:28.314691+00
18	49	\N	2026-04-20 04:51:28.948873+00
19	49	\N	2026-04-20 04:52:31.232614+00
20	52	\N	2026-04-22 06:55:07.735242+00
21	52	\N	2026-04-22 06:55:12.66803+00
22	52	\N	2026-04-22 06:55:13.949487+00
23	52	\N	2026-04-22 06:55:14.920472+00
24	52	\N	2026-04-22 06:55:15.439486+00
\.


--
-- Data for Name: campaigns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.campaigns (id, uuid, name, subject, from_email, body, body_source, altbody, content_type, send_at, headers, attribs, status, tags, type, messenger, template_id, to_send, sent, max_subscriber_id, last_subscriber_id, archive, archive_slug, archive_template_id, archive_meta, started_at, created_at, updated_at) FROM stdin;
49	4923d55a-24f5-4eae-96c3-ffa8fe4fe6ec	Media Training Workshops	Got a Story to Tell?🎙️Media Workshops Starting Soon!	StreetVoices <communications@streetvoices.ca>	<p>Hi {{ .Subscriber.FirstName }},</p>\n<p>Have you ever wanted to start a podcast, improve your public speaking, or learn how to tell powerful stories through photos and video?</p>\n<p>Street Voices is excited to launch our <strong>8-week Media Training Workshop</strong>, designed to help you build real-world media skills in a hands-on, creative environment.</p>\n<p>From <strong>April 8 to May 27 (6PM–8PM)</strong>, you’ll explore:<br />• Intro to podcasting 🎙️<br />• Public speaking &amp; storytelling<br />• Photojournalism 📸<br />• Videography basics 🎥<br />• Networking and collaboration</p>\n<p>Whether you're just starting out or looking to grow your skills, this program is all about helping you find your voice and bring your ideas to life.</p>\n<p>📍 Location: Toronto Public Library – Lillian H. Smith Branch<br />💻 Register now: <a href="http://www.streetvoices.ca/">www.streetvoices.ca</a></p>\n<p>Spots are limited, so don’t wait too long to sign up.</p>\n<p>We’d love to see you there.</p>\n<p>Best,<br />Street Voices Team</p>\n<p><img src="__SV_ROOT_URL__/uploads/MTW_flyer_front-APR2026-(2).png" alt="" width="520" height="650" /></p>	\N	\N	richtext	\N	[]	{}	finished	\N	regular	email	34	1	1	34	34	f	\N	\N	{}	2026-04-20 04:50:53.177502+00	2026-04-20 04:46:21.358922+00	2026-04-20 04:50:55.126752+00
52	b3f64587-7241-43a4-8c47-b544d50d4bb1	April's Wins: New Partnerships & More! 🎉	April's Wins: New Partnerships & More! 🎉	StreetVoices <communications@streetvoices.ca>	Hi {{ .Subscriber.FirstName }},<br><br>What a month April was for our community! 🎉 We're so excited to share some big wins and milestones we reached together, thanks to your incredible support. These achievements truly highlight the power of working together.<br><br>Here’s a quick look at what happened in April:<br><ul><li>We kicked off a new partnership with the Toronto Public Library (TPL)! 📚 This collaboration will bring even more accessible resources and engaging programs to our neighborhoods.</li><li>Our youth program celebrated 12 amazing graduates! 🎓 We saw these young leaders grow, gain new skills, and step confidently into their next chapters.</li><li>We opened two new pop-up clinics 📍, bringing essential health services and support directly to communities that need them most, making care more accessible.</li></ul>Want to dive deeper into these inspiring stories and see the full impact of your involvement? Read all about April's successes and more on our blog. Your continued engagement makes all this vital work possible! 🙏<br><br><p style="margin-top:24px;"><a href="https://streetvoices.ca/blog" style="display:inline-block;background-color:#ffd600;color:#000000;text-decoration:none;font-weight:bold;padding:12px 24px;border-radius:4px;text-transform:uppercase;letter-spacing:0.5px;">Read Our April Wins</a></p><br>In community,<br><strong>The Street Voices team</strong>	\N	\N	html	\N	[]	{}	finished	{ai-drafted}	regular	email	34	3	3	36	36	f	\N	\N	{}	2026-04-22 06:54:53.352164+00	2026-04-22 06:54:19.076946+00	2026-04-22 06:54:55.212907+00
\.


--
-- Data for Name: link_clicks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.link_clicks (id, campaign_id, link_id, subscriber_id, created_at) FROM stdin;
\.


--
-- Data for Name: links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.links (id, uuid, url, created_at) FROM stdin;
\.


--
-- Data for Name: lists; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lists (id, uuid, name, type, optin, status, tags, description, created_at, updated_at) FROM stdin;
37	d7fc3046-2dfb-4305-bb9e-da65da6ba978	Volunteers	private	single	active	{volunteers,internal}	Volunteer roster managed by Street Voices staff. Not self-signup.	2026-04-20 04:21:40.112622+00	2026-04-20 04:21:40.112622+00
38	f06a5681-678e-468a-80c4-a4046bff496b	Donors	private	single	active	{donors,internal}	Donor communications, impact reports, and stewardship.	2026-04-20 04:21:40.129134+00	2026-04-20 04:21:40.129134+00
39	e8fa222b-0809-4058-96ea-90b7cec55c11	Partners & Press	private	single	active	{partners,press,internal}	Partner organizations, journalists, and external stakeholders.	2026-04-20 04:21:40.149109+00	2026-04-20 04:21:40.149109+00
40	a13c9ea2-35f6-4553-b55a-9daac448d0fe	Internal / Team	private	single	active	{internal,team,test}	Staff, board, and contractors — used for QA test sends and internal comms.	2026-04-20 04:21:40.164834+00	2026-04-20 04:21:40.164834+00
35	49e58929-5e9b-4e16-9273-c405c7060aa2	Newsletter	public	single	active	{newsletter,public}	Main public newsletter — community updates, stories, and announcements from Street Voices.	2026-04-20 04:21:40.060852+00	2026-04-21 01:03:25.368803+00
36	685e957b-86de-46b7-a267-b99b910842ad	Community / Members	public	single	active	{members,public}	Active community participants — deeper updates, member-only content.	2026-04-20 04:21:40.096232+00	2026-04-21 01:03:25.402538+00
\.


--
-- Data for Name: media; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.media (id, uuid, provider, filename, content_type, thumb, meta, created_at) FROM stdin;
4	465701a1-0389-4ceb-b9e9-13ad7b5969d7	filesystem	Street-voices-logo.png	image/png	thumb_Street-voices-logo.png	{"width": 1600, "height": 1587}	2026-04-20 03:13:58.777596+00
5	47af50d0-78ff-464d-a268-4eb3df198446	filesystem	MTW_flyer_front-APR2026-(2).png	image/png	thumb_MTW_flyer_front-APR2026-(2).png	{"width": 1080, "height": 1350}	2026-04-20 03:22:45.110558+00
6	1f26b962-7351-4ba9-81c3-d0fd41deb446	filesystem	instagram.png	image/png	thumb_instagram.png	{"width": 30, "height": 31}	2026-04-20 04:07:25.373073+00
7	38289164-f4dc-481e-9ec2-c4405328e7dd	filesystem	facebook.png	image/png	thumb_facebook.png	{"width": 28, "height": 27}	2026-04-20 04:07:25.398489+00
8	ae0ca509-15f7-4f7e-9c8f-8417120bb816	filesystem	twitter.png	image/png	thumb_twitter.png	{"width": 34, "height": 29}	2026-04-20 04:07:25.405324+00
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, type, parent_id, list_id, permissions, name, created_at, updated_at) FROM stdin;
1	user	\N	\N	{subscribers:get_all,campaigns:get_all,campaigns:get_analytics,campaigns:send,webhooks:post_bounce,templates:get,settings:get,settings:maintain,lists:manage_all,tx:send,bounces:get,bounces:manage,media:manage,users:get,lists:get_all,subscribers:get,subscribers:import,campaigns:manage,media:get,templates:manage,settings:manage,subscribers:manage,subscribers:sql_query,campaigns:get,campaigns:manage_all,users:manage,roles:get,roles:manage}	Super Admin	2026-04-17 17:32:17.959557+00	2026-04-17 17:32:17.959557+00
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sessions (id, data, created_at) FROM stdin;
JAGQMTjCdOEUR5dQMwEjxEn9pU1mQcpdK62N56VvWT9GfgSHAMW4lYPKdlPpfJ8k	{"user_id": 34, "oidc_token": ""}	2026-04-24 21:07:46.80483
33a8vtJeK4cQM62Z8j3Pmy6uAA6TX9lTiExIfL88coqDjnWaujRCxygH95twh4CN	{"user_id": 1, "oidc_token": ""}	2026-04-24 00:04:27.368654
GCw2oaVSxxjC5M3O11oLd3lbKqXIHZFe0POecDsUa6iIwsrTdI424NtAWtECZK13	{"user_id": 1, "oidc_token": ""}	2026-04-24 00:06:28.709994
ektHY9tLce2k32Lzv8lKIl2C0nRr9zTvux453SeUyVywLejbx5p5Dd0BWmzoJpex	{"user_id": 1, "oidc_token": ""}	2026-04-24 00:06:34.115313
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.settings (key, value, updated_at) FROM stdin;
smtp	[{"host": "smtp.sendgrid.net", "name": "email-sendgrid", "port": 587, "uuid": "0fdce066-f66e-43b9-843f-b72473a9d5e8", "enabled": true, "password": "", "tls_type": "STARTTLS", "username": "apikey", "max_conns": 10, "idle_timeout": "15s", "wait_timeout": "5s", "auth_protocol": "login", "email_headers": [], "hello_hostname": "", "max_msg_retries": 2, "tls_skip_verify": false}]	2026-04-17 17:32:05.899219+00
app.lang	"en"	2026-04-17 17:32:05.899219+00
messengers	[]	2026-04-17 17:32:05.899219+00
app.logo_url	"__SV_ROOT_URL__/uploads/Street-voices-logo.png"	2026-04-17 17:32:05.899219+00
app.root_url	"__SV_ROOT_URL__"	2026-04-17 17:32:05.899219+00
app.site_name	"Street Voices"	2026-04-17 17:32:05.899219+00
security.oidc	{"enabled": false, "client_id": "", "provider_url": "", "client_secret": "", "provider_name": "", "auto_create_users": false, "default_list_role_id": null, "default_user_role_id": null}	2026-04-17 17:32:05.899219+00
upload.s3.url	"https://ap-south-1.s3.amazonaws.com"	2026-04-17 17:32:05.899219+00
app.batch_size	1000	2026-04-17 17:32:05.899219+00
app.from_email	"StreetVoices <communications@streetvoices.ca>"	2026-04-17 17:32:05.899219+00
bounce.enabled	false	2026-04-17 17:32:05.899219+00
maintenance.db	{"vacuum": false, "vacuum_cron_interval": "0 2 * * *"}	2026-04-17 17:32:05.899219+00
app.cache_slow_queries_interval	"0 3 * * *"	2026-04-17 17:32:05.899219+00
upload.max_file_size	5000	2026-04-17 17:32:05.899219+00
app.message_sliding_window_rate	10000	2026-04-17 17:32:05.899219+00
upload.s3.aws_secret_access_key	""	2026-04-17 17:32:05.899219+00
migrations	["v6.1.0"]	2026-04-17 17:32:15.762911+00
bounce.actions	{"hard": {"count": 1, "action": "blocklist"}, "soft": {"count": 2, "action": "none"}, "complaint": {"count": 1, "action": "blocklist"}}	2026-04-17 17:32:05.899219+00
app.concurrency	10	2026-04-17 17:32:05.899219+00
app.favicon_url	"__SV_ROOT_URL__/uploads/Street-voices-logo.png"	2026-04-17 17:32:05.899219+00
bounce.postmark	{"enabled": false, "password": "", "username": ""}	2026-04-17 17:32:05.899219+00
upload.provider	"filesystem"	2026-04-17 17:32:05.899219+00
app.message_rate	10	2026-04-17 17:32:05.899219+00
bounce.mailboxes	[{"host": "pop.yoursite.com", "port": 995, "type": "pop", "uuid": "f297d182-e07e-4e49-aabf-193be232505e", "enabled": false, "password": "••••••••", "username": "username", "return_path": "bounce@listmonk.yoursite.com", "tls_enabled": true, "auth_protocol": "userpass", "scan_interval": "15m", "tls_skip_verify": false}]	2026-04-17 17:32:05.899219+00
security.captcha	{"altcha": {"enabled": false, "complexity": 300000}, "hcaptcha": {"key": "", "secret": "", "enabled": false}}	2026-04-17 17:32:05.899219+00
upload.s3.bucket	""	2026-04-17 17:32:05.899219+00
upload.s3.expiry	"167h"	2026-04-17 17:32:05.899219+00
app.check_updates	true	2026-04-17 17:32:05.899219+00
app.notify_emails	[]	2026-04-17 17:32:05.899219+00
bounce.lettermint	{"key": "", "enabled": false}	2026-04-17 17:32:05.899219+00
upload.extensions	["jpg", "jpeg", "png", "gif", "svg", "*"]	2026-04-17 17:32:05.899219+00
bounce.ses_enabled	false	2026-04-17 17:32:05.899219+00
privacy.allow_wipe	true	2026-04-17 17:32:05.899219+00
privacy.exportable	["profile", "subscriptions", "campaign_views", "link_clicks"]	2026-04-17 17:32:05.899219+00
app.max_send_errors	1000	2026-04-17 17:32:05.899219+00
bounce.forwardemail	{"key": "", "enabled": false}	2026-04-17 17:32:05.899219+00
bounce.sendgrid_key	""	2026-04-17 17:32:05.899219+00
privacy.allow_export	true	2026-04-17 17:32:05.899219+00
upload.s3.public_url	""	2026-04-17 17:32:05.899219+00
security.cors_origins	[]	2026-04-17 17:32:05.899219+00
upload.s3.bucket_path	"/"	2026-04-17 17:32:05.899219+00
upload.s3.bucket_type	"public"	2026-04-17 17:32:05.899219+00
app.cache_slow_queries	false	2026-04-17 17:32:05.899219+00
bounce.sendgrid_enabled	false	2026-04-17 17:32:05.899219+00
bounce.webhooks_enabled	false	2026-04-17 17:32:05.899219+00
privacy.allow_blocklist	true	2026-04-17 17:32:05.899219+00
privacy.record_optin_ip	false	2026-04-17 17:32:05.899219+00
upload.s3.bucket_domain	""	2026-04-17 17:32:05.899219+00
privacy.disable_tracking	false	2026-04-17 17:32:05.899219+00
privacy.domain_allowlist	[]	2026-04-17 17:32:05.899219+00
privacy.domain_blocklist	[]	2026-04-17 17:32:05.899219+00
app.enable_public_archive	true	2026-04-17 17:32:05.899219+00
privacy.allow_preferences	true	2026-04-17 17:32:05.899219+00
app.message_sliding_window	false	2026-04-17 17:32:05.899219+00
appearance.admin.custom_js	"\\n(function () {\\n  // EARLY HIDE — injected style to prevent flash of Listmonk's dashboard on load/nav\\n  (function earlyHide() {\\n    function applyClass() {\\n      var p = location.pathname.replace(/\\\\/$/, '');\\n      var isDash = p === '/admin' || /\\\\/admin\\\\/dashboard$/.test(p);\\n      var root = document.documentElement;\\n      if (isDash) root.classList.add('sv-dash'); else root.classList.remove('sv-dash');\\n    }\\n    applyClass();\\n    if (!document.getElementById('sv-early-hide')) {\\n      var style = document.createElement('style');\\n      style.id = 'sv-early-hide';\\n      style.textContent = 'html.sv-dash section.section > .dashboard, html.sv-dash section.section > .tile.is-ancestor, html.sv-dash section.section > .columns:not(.sv-keep), html.sv-dash section.section > h1:first-of-type, html.sv-dash section.section > h4:first-of-type { opacity: 0 !important; transition: none !important; }';\\n      (document.head || document.documentElement).appendChild(style);\\n    }\\n    window.addEventListener('popstate', applyClass);\\n    window.addEventListener('hashchange', applyClass);\\n    setInterval(applyClass, 500);\\n  })();\\n\\n  var LOGO_URI = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPoAAAD4CAYAAADFJPs2AAA9/UlEQVR4nOydB7hUxdnHf1tugUuXjigYRUUUKzYQURGxYa+xxHy2L5pEY9Ro8mmMSdQvtpiYYoslxt7bp8GGDTsW7MEKgij1ctuW75kz79ydPXu23bq7d/7Pc569u3fP7Jxz5j9vnXeiOJQskvMDPw75jrRTgIS8tgeq3XCW9u0j/aTx7fxVh06D/0E6dANyENommyJWvIhma4BqOarkiPraawFi8tosR1MRvxGx2ku4CaB04YjeDQggtp/UsRyn9weGAqPkGAkMl2MtYCDQR45ai+hRHzHNxGETvQFYLccy4Fvga2CRHF8CC4FvgBVZ+heS3yEb+R3xux6O6F2APMROyOHHYGA9YCNgY2BDYKyQe5BFpq6Gmhi+E9IvAD4A5svrApkc/AjLEWhaOOJ3PhzROwkB5LYHu18F7yeE3grYGpgoJB+Y4yeCJohQlteCu53lFcsnEM5xvpoAPgbmAa8CrwPvi4ZgI5JtknOk7xw4oncgfOS2ieFXxRWxNwd2AnYUYo8IatKSgH4HXHc9O3sSSFp9C3LeIZJfEX8O8Jz8bRPfqPqO9J0IR/R2Iofk9pNbSexpwO7AtgHEtiV9OItXvdThV82DojqK+C8BTwBPAR/5/h91pO94lNtAKhn4CB5E7rCo4XsBM4EtfAPfEDuXNKwE2A65iO86m4HXgEeBR+RvAyPp47YJ4QjfNlTq4OoUBKjmxl61bW5lZ+8P7Ats6msi1gOInQ+2xPc7FJVN/wBwL/CW9bn5Xppvw5G+cPTUwVYUAgge8UnvdYXch4la3nqqDM5yVcU7G7aqb2s76rMXgNuA+4CvrP9FnZQvHm7g5UCAeh6ypEpE7O1jRD3vY303ZqnzDoXD2OY26VcADwI3ArN99n+aLe8Inx2O6AHIQ/DhwOHAscBm1vccuTsOSYvAtnqvbPjrgduteH3E931H+AA4olsIIDjWANoYOBE4UpJZsNTOnmxzdzYMiW2fyCLgZuAaidvjCJ8bbnDmJ/g2wI+BgyV/HJ+33KHrkLC89wprgH8BfwLelM8c4QPQo4meR0XfDjgDOMCXg+4PETl0PYyT09jyMVHnLxPPPVYSjnPa9dQBm8eLviVwtkhwg7hTz0sSRnLb4Tcl4S8G3pHPnJe+pw3cgCy2iCXB1xeCH+tT/7pr8YhD4fA/qybgOiH85/KZ/ax7HNl7DNED1HSTrTUQ+JnY4X3l/3FH8LKF/ey+Ay4HrpD8er//pccQvuKJnkdNPwY4Hxgj7x3BKwN+G/4D4Dyx4+mJ6nxFE91Hclt121rUul3kvXOyVSb8hH9EzLO35X2PUecrcmBnyUlXD7QO+JWo6lEXJusxsMNyDTLJXyS2fJp0r1SyVxzRc0jx3cVW21jeOzW958F+5m8APwWelfcVLd0rSpL5SG5m6r7AVcD/CcmNfe5I3vNgoikxWTb8tEj3Wp+Kn61gZ9miIiR6Do/6VOAvQvCE9X8Hh4S1olBJ95OBuZXqmS/7QR8gxc0DOh940pLibsGJgw2TAGWk+xzgTGtFXKvGVwnSvawlegDJY1Ip9VrxqCetRScODtlgS/eHgROkrHXUrjtQzpK9LImepQijelizgL9L3fNYlpplDg5BsENxXwLHSV27isiZLztJF+BVN+mPF0g1kqF+x4qDQwEIWRJ8bXHenmWF3lq5Uo6qfFlJ9Cyq+kDgH1KjLeFKNjl0AGzH7b9ElV9dziG4siFEFpJvAtwBjHequkMHw1blXwcOAT4pV7u9LFT3LCSfKZ5SR3KHzoCtym8JPC/h2lg5xttLnujWjbQXpJwk3tGBzh536GSYxKthwONSSixm70xbDmQvaaL7SG6qv/xakmDcenGHroLxvFcBt0i8PWYXIyl1spesjW7dODvT7a9SoNGtNnPoDtjC5VIpNWaPz5K12UuSKD6Smzrf/xSHiLPHHboTtpPuOuC/fLkcJUn2kiN6AMlrgbuBPR3JHUoILaLK3y52e6KUyV5SRA8geW/gfmA368Y6OJQKzJi8z9I2S5LsJUP0AJL3kq14dnWS3KGEYcj+sOy/Z2LsJWWzl4TXPcDxViu7au4qN9KR3KFUUSVjdC/gTv+GmqXije92ovtCaIhH8x5R12NOXXcoAxiyzwJuFY20pEJv3Up0H8mNyv4vyXpzktyhnGDIfohsBBm3Q8DdTfZuI3pAxltclpge5BxvDmUKQ/YfAH+w8j08dCfZu4XoAUtN1Q25EDjekdyhzGHI/jMrg67bc+O73OueZYHKycDVzrvuUCGwk2q+L8leraveusMT351ENxe+J/CQ34Hh4FDmSFqE303KSreuZ+9qsncpqSySmwueALwA9HG13RwqEEZ4fQNsCyywnM5dSvYuI3pAGG2AlNfdwG2m4FDBMGN7HrAD0Ngdi2C6RIIGeNiTYrds4PdMOjhUGIyzeSJwQ3eVku5qVdlc9O9crNyhB8H4ow6RgpNd7nTudNU9wC7fD7jXedgdehiSlho/HZjdlc65TiV6wEKVsVJor5/1uYNDT4FZyrpYdodZ3FWr3TqNaAFloCJShmeA87A79FAYgTdcSpR3GQ+64keMevIb8To655tDT4bxU83wZ851pmOuU1T3ALt8Z+ApV+vNwcFD0trmaTvgtc621ztcovtU9qTY4zdYaoojuUNPR8iqG3+j1F+gM7nRmaq7KZF7KTBGZitnlzs4aISt3YYutJPGOkOF79AZJEBl3wN41IXSHBwCkbTSZCdLOninqPCdIWGNyt7X2mjBSXIHh0yErOPvQI31eYeiwwgYEDP/jVPZHRzywlbhf9FZKnyHzBwBKvs2wEvOAefgUBCMCq8IvznwQUcn0nSGpFVtXmW17Uju4JAbhiM1wp1kR/Om3UQPkObHydpbt/TUwaFwRKwiFQd3tArf7llDOmEcCgOA94DB8m9nmzs4FA6TC/+ZFGVpMGvX26u+t4uIAQ64c4GhVsjAwcGhcIRFko8BTrfXrrdXqrdLosuPm91V1gfeliqYIWebOzi0Cab6TD2wMbDQOObaI9XbLHUDUl0vFGdChzsSHBx6EIy3vS/wPzaf2iPV26te2+G0g/xlchwcHNoEkz5+LLBRR5jCbTo5YGa5wFLhHRwc2gcj1auB8ztCqrdnljDSfEfJaXfS3MGh4xAVTilNedP28qtoolszipHe/+N77+Dg0DEw5P6lza+2SPW2SnRjQ2wP7O6kuYNDp8BI9QMkrt5mW72okwJmkrPNv9ry4w4ODnmREML/vD22eltmByPN1Qyzl/y4k+YODp0Ds+HJIVJFuU1SveATfDOI+uGf2ovkHRwcOgUh4Vgt8KO21ncoOLHFyoJTM8oo4H2grth2HBwcioYxjb+TbcyWm88LzZYrdmYw3z9WdkCNO5I7OHQ6jFRfCziyLeZyQSS1Vqghaa7vSeK9W7zi4NA1MFx7R4pTJIrZkbUYkhqnwExXIsrBocsRtpzgU4uV6sUQNSGvJ7hwmoNDt8DmYFHIq7r7nHDfA+ZbS1EdHBy6DiaOvhoYBywyq0fzqe+FSnTzvSMk0d6F1Bwcuh4hKSDZR3LgKVR9z0l0K3Yel+ycwws5z8HBodNgNOnvy2tBQrcQwhon3CSpeOE87Q4O3QfDx61lVZuXQJMvJbYQwpoZ5DB5TbS3pw4ODu2CiXgdLO/z8jjfF4xNUAPsW2ijDg4OnQrDwf2tgpIFnZABy9uO7OG8rlPbHRxKAqaa0yaSPOPF1HOp74VIdIX95NWp7Q4OpQGTfr6PvM8Z7s5HdONtn1ng9x0cHLoGhth7W7nwWRFIXF+99k0lOO+2P3ZwKB0YLk6UPRVyet9zEdf8b/dCZgwHB4cuhXGUVwG7yGdZ+ZyL6MYe391q2MHBofQwQ16zrkHJRnRTV3qIBOZzfdfBwaF7YNJfd8hXHyKDvL6w2iSgnysw4eBQkjACeRiwhXwWaKfnkujIulfcslQHh5KFMbF3ktfCJLrv5B1znezg4NDtMNycIq+BuS5BRLft801zfM/BwaH7Ybi5hdjpiSDBnEZgn32+mWzdGniig4NDScBsWz4UMOUnMgRzNomObIVMT0h79XaeT6YOB4cyg8lx2UpeQ36HXDTgJDPUDdErUponEpBIQjgE4YivTkcc4nFZKRCGUJY7EE9AsoOmwXBYHzZi8Ta4QUP6gYVz9NtGh1xDCKK+Oife/e2Adv3333suHTQZB93zMofi7F+C/uEnesjKb59gfVYxUIPPI0IdhKuBZojXw+pVegCpgdW3D0T6i76zBuJNEPEX7FHfrZMFvB2BJv1brXdbkWdgG7wjScmXatL9ViTJOpg76hoUoVdZk5KaQHtDuLad7SalOlospaBG+kkuWEegAWisiBFum9sEZbEGET0pO7GMsT6rCChp4A3sELzyKjzwFMydB599Bd+t0ERXkmnYYNj4e7Db9rDvbjB0NCRX6DYUcdT3QjXw7Bx4/IXUZ22BOXfmFNhxW0g0QigCLXG4/lr48uvC21eEHjEExo2BiRvC4NFAi57I/BOVp83UwlPPwOyX2nYN5pxha8EJh0J1FSTjut033oB7Z7fRHJJR2K9OtzugPyRaIFwD9z8Ir7zT/nuu7tXBM2DCeEg0ac2ujGF6vz4wGFhqcTntCx6S81v3UpsOPF5J6889kveHd9+FMy+CR54p7Lyha8EZP4SfnwjJFkjGIBSFxiYYuwss/rZj+rfuSPjoCYgoAvaF2bNht+Pa3t7ggbDnVDj9hzBxC0gsT0n2pFQEr18DY3aBb5e3v/93XQEHHgixZRDtBVvsA2++3/52L/4ZnHkaJFfBkm9h1FT9LDsCk7eCOXdBor4iVHhTIXY7YK56wqHxKcneKtF9u7EY711FED0hJH9iNhx0Cqys17O6UtNtR5yB+l9IbF01uM68BF59C/75R5EGIWhuFA0g6ps6i4Spo63aSjRDtFo/hfoGLYWVhhEvxtZNamm9dBncdB/c9jBcdAacdjLEV+pr9q4xDI2Nuu32XIPqXywGK1eLfyCkzSE1Eap21b1KtKFh0+6qeulvSPdXaQ0tofZJ9EgI4kloatYaTyG+jDKAMbk3Do1nbnJ+uhAPcsZhEb3soQZZqBd89gkcfKomuRqAahDFZL5Ts3kkkhrpccuRpAZBVRTueAzGXAQX/1rboyFxEql22jPoDBG8wWY9GtWnuDjjiiI6qX4rUrfE4PTfQ3MznHUaxJelpJeZ0Np1DUl9H9NMA1GNVbvqtU1OuYB2Tb/be8+TYX1PvfYqg+Q2NjYed/Vq6r37pbV5JOPktexvQzIBoVr49R9hxWpNWjVQDNSAUQPRED/m8+qqvxVZ1IC77Cb4+F2gd0p9jEbSjwynXQAikczz9I8Vfl3GG20ONWhVO0Y6JZOpiUx9fval8PLzEOmbPnHkIouahNSk6O9r2hHVfbHvab52Q4W0K/fSbtdzpIYCvpdH5wwFPCd1eH2snHCq4epG8pp2ZVHfFxPi01zHd3JZwvOiV8OKhdrxpgaJbd8ZqTBuDByxHwwdBO9/AjfeA6vXpNqA1GC+bzacMREiUWhuSZGpGATZmKqtcJU4+gppI5F5rUGC0ybcBVfDQ9sV/lCVppGI5f6Ouf7BgwrPuPAmoWLaFUIqtX1NQ2G/kfZ7pD+ntGcWhWRzRajv5grGBtWPCFLdhwDDfSeXJRJC9I8+0w6nkGUvmgc7fDA8ewsMW19CLQNhy43g2F+kt9Usg/iVd3S4p29fuP638MizKa0gUgVfLYSHn9XfDZJqSkrN2gWGrAVxUW3V1/adBlW9oKU+TzWQkP7+2cfDXrtrL71qY3UT/HsOXHlTaiAnLVNE9XH2S/DFxzB6ndxlRIw5seFYOPFIiJp75vueuZ/D1oK9pkFydW6NxkysI4bAT38AvauzTGziMOhTB4fuCdRrzWz4CLjhd/DCG9Y9V8/3E3hybqY6b/wOtTWw/3ToWycanpg1R+1rubDKH+YqRsiK0xW2590v0dWHI7VyWiG3IAyrVusLsR1OZqAM7A/D1tGDKVYP8TWw4xYwYQNNmJCc5BEyCXtM1pIr0Qz77QP7HWA3qo+p+8Kzr+pBb6S3+XvGZLj7Vl/8NqSdQqoPucI8hlj9+8J5/w01Q7Tjy7QzYxasvw6cdL4eyHHpl8kPaGyC19+D0Rvo38r6O1JA+Dc/hoN/ACzLsfGP6e+q/FqwpxXF4SdHwZnnyrb+uUydsMTRhZxqgj32+3DsMdY9j+jvbDwD3v9Puk/AU/3jcMIhcOVVwErLWA1J7kJD2YfWDMxVDBJBnZ3oynBPzveIjihiRW22XqpQarZ/1lKDQT1gNThOORuOOhgmjIW6PrD+ZvD243oQ2A47b0BUa5J4xF2dLkEUkasGwMB+mX0wv63+F2+Alm+1ndr6/1B+W9P+7qp6iNZIuC8kkmoNHHeAVtEXLkmXcEaD+XRh4XGUqHFQ5lrtkAiO0+dsN1pAu0kdJQiHfJlxK9InFHXdVXU6DKqeZVpz8mbEYP2s/Pc8nCuZqDxhomQjQ+P5wPa8+yU6ln1e9m4K74JiMHytlES1pbpR4/98qz7GrA3bTYSdt9Ux1o3HQnSQqLn1OkyHlVzhJ6YJveWy2z1PstIOoplpo8XARAqMKopoHJEarRr7iW6gpLqHHE/XpMSe/2dY0QQ1AWQ0GpEi2G476kSZfDB+hStvhj79oH/vVKaiv12lZs/cSbQLq6/+CSUZzm/ze85U9b1I++55GcAQfZS8DyS6waiu61fnwlO3m2C9sbDBuvDhp+Kl8DmN1OBRg+vTL/Vx28P63I3Wgylbwz67aJXd81ivzK/n5HLsdJTTR/XXy/uOp1T6cFSnvS78Rn/HT3L1071rrTfZ2pbz3voAfvDz/H159haYMhniq3JLdtOfLxbBSb/M3+6tf4DDD4XY8twEDYW65p6XEdb2f+DJJDvuJmVpKgZKCkf7wunHiPMmkmmTmYUS6nMT+lLfnf8x/O022PsEmHQwzH4aIgPaFtfuSKi+Komn+hLtr5OBqtTrMLj6Vli0RCSYRXRFXvV2vdGFe8dNyC6S5aip1iRSv0e0cBXQhMiytVtbrfu/5NtKSNfqFmRw2JboSd+XKmIe9KT1Cjj+KHjpLbj+7tTniJpqJJj3Kipoa3xa1N/X34XdjoFbL4XDD9ZthrtYDTST0crVcO6VMH0aJBokyy0O//c0/P128ZpbZDYqfJ/esPUm4ggsgEDeCrQC+lQVLc7Qs2P8QTBaVzRbOpdDPgz1J83Yt9I800Hd0bPOhJcg0ATX/S9stjH8QRaL2DCqoVm+atJiE9b/1eD74Tmw7UQYOyYV2upKmEnp0hv0UQiMt3vWLjBsjOSjF7CyLBRKzxjMaFdGT7G5562Oxyx5t4bg3a05lSGMcB4ir6130A42mJ1YBvhOKnt40jmhpd9PToK3HoQbL4ZD9oSxYs2YrDhDpKC14YrsDU3w55t1Wm1bcrg7CpFwaj2155gLB9uxYUn3rK2B804tLjnEOLnMvfEfTU2a5MqMaItEz9Z2Y5N+7dVRS4B7HgyHW5+KXzmqlvJRFYVEMhVHj30HA/vC0UfA0YdDw3fw3gJ48Q147jWY+xYs+CI4P9sknjz5cv7kkM5GIdIuZKnwN/wONhgP8eX5tRCj6g8fDEfMguoAqW4cgCOHwLQdIFlfQCpqKOVfOHp/vQzVX/TCfKd/Hzh0po6RFxp2dGgVzv2s9VKeEPcTvRdQgF+2jJDU65g9JGR1mCloEIJefWHLibDlJPhRHBqWwfzP4VeXwKNz0hMwjDq/cAmsXgl9+6Xi2F2NSCRFiiDV2ay+W2ckXPYLOGB/vaAlEsm/GMSo+r87DX5wKrA8R6QhIfdS3Zs898FOmPnNxZLSka1dq+hED/Satxd1IrQbzQetRJdkmdoOrJnS7fCSYnrDy6/AT3+vVUVbNVcD6KLTYfJkiC3RTqWaCGy1JVz1Sxi3RyrOa3MjLqWmunMqDMrZt2FWv13yczjgSGj+HKqrC2vbNDVqqC640bLMSnLxIWQvGS3wfowerqvpNOdo16yAq4h10l0H8wRq5MgguhnLNTITVARMFZXnXocX3wz+zhU3wbS9ocp43JN6Wc9Xi8Vp4cuPVwN6YH/ok3MDnM6D6cNBM2DKzvDOa3DNXZlkN3+f/yfYcxdt77Ym1xSIh56B7SdDJC5mS8B3vEFTpe9zsin3/TB9emQOHLw/1CYg3py93WgEqnpLqqqT6sXAI7oIbw9BNnrFBDVMZtyE9VOxW3vAhsLw0NNw1llw/JEwrD80NMNLc+BnF2a254XaQjBpUx2/VvZuV9rpto17w2+hzzrAsfDZInj8+fTcepMz8N4n8Ps/w2/Ph9jSwkJWpo2rboE7H9OaTjaJrT7qUwf/uhQmbqodntl8AMavcP9sGDcVevUSGz2gXXWvq6rgL+fB9F11Cquz1QtG1KqsF2ijV1WSphSW4o47bKWXoH6zTH/e6siS10uug8tvhMFrQUMDLF+ZasPWKg3RfnhA91a7V2RtaobaJVqSXnoWbHVgQIpvQpPjf2+Aw/aCTTfTeemFLuJQ1/v10sK++8zLMHESJNbkH0Cq3aXLxfbPgydegOkzXRnuIhHxC2z/M/HVCSlveOvPW6DPUDjnBD3w7eIMBkrytcRg0WJN8tYFLBa8EkYxOHxP2GVXSKzqPgmTlIo00WpN3Albw8mH6gnM1jAMOVpa9Io25LxCOWN+J5zjqI7q+6XuT6ENF9OuF2JzJC8WeYlecfDU2RXw4+P1+uPmFv151EqFjcfTq7WYpBmj7ns14lpgl23hmoulUmuOadAMVnswh0KZK7FywVSNsc+zq8m0/lZETzr/82NdvdZb2BJJnZeQzLUX3oC/3QjhfumOvLCvUo3/IFX3IeMgBwfNZBnU//a0m/Weh7Pc8wLr21cYQn5BXfFExwQUm+Cmy+Dck6WclJUcE5GEk0gk9WrU9Jhs5HDK9+Hh66GuBkK5CgqGYE2jbtt4+RNSjiphChLmG3ghLYW9ElfxVKaeeq9eV9enmOD5DZpg0Ci44FQt1U3uvjmvRVZ2/eJKaPwOopb0Xb0mve1ijtbrSsgEaq2vr2/Q/4/H0zMNi223oUBHnLqORDJ1v7w25B4WdM8rHBXjeMuFkBTJSjbDhefCoXvBX26Fx+fAJ19kTz5ZZwRMnwwnHgbbTJJKJ82ydDIbktoe/mCBLLmWts2CmcP2zB0b9tpuhM3Hw8SNYMl3qXx7E9OfvgP0X0uXn/akVlTn3v/wMHj8OXhhnp6wWn9b/t51e72G3SucEYMBa2lTRNnBbSriKA6Bfn1g6iTZECGpMzGO3Af+cW960k5RTYe0ObDrdrq4Rrb75VURisJ+u+pFMPbvqb+V6j99R31PK2zteS5kVMPzbl9yPuHQeBLJ+WwCvGN9ueLmwdZNHKqh6VtdrECR/YuvtVSorYa1h8P3RutNHOqGaGLGVxehBtZAw8p0D78JF9X2LWB3kKTun5pU6hsy12TX9ZPQXsJ3TkSrL/WrgvPIM84LS333lQXfvnRIwYvaGl3LvTUMFtJu3TUr2+hEC6UWy9TUFRheq/b9nvStprpHheiSVu2cjULj+dRw2y/RWyqllns2eKvZ1uiUzZoamLg5TNxarjhkVT4x2xottxZ3FAhlw/fq5a9dJTXXGwvweodSOel9+mYSNjBfXcoBJuNQVxfcbMZ5idzfLwhGW2qy2k7q9717t7PdZOG7qCSCfi+obz0DceFyK4KIHqukpJkgtO5YEteET8pabVuHMc6ctsTJPVU7y4quYkJbXp8CKqfk8g+EyP7bQeeFcvS1GPjb7qh2C71fue55DyM5MmrMyEmrGWdkRpOQvSKJHrjarMBaba2TQebpWQkU2IdEcD/CocxKKSEKUzez9a2YScXulx1etJ16IfHyF9JsR6zsK6T/rY7EgP+FAlYh9hA02emvBGzJ1Chfao8yV7IIB2XxJ/Mv3fQGeVRvfpiBWKqcU67z45K8Eu4lu7iG0/vgTa+Nqd1NCiWp17fqLL/fnP/8eFx+r7fcn6Q13ct1R2pkpMRkd9lY/pJR4ep22sR5novxf6g+e/0L6o/U+Is3ZoYlKxRGJ1VPvtneI92vujdYM0HlOOOkeOKXActP1YAdNSJHnXMh0oplsGJVKuxmXocOgto+2Qel5/yr0imz6u5+/DG8+Z7OpV++CnrV6uWgEzaACeOgepD+XryhALNB+rb4ax1C8ld9HT0yyP8qp4qU9raHboY33oJn58Ib78nusit1qKqmCkYNh83GwbTtYOdJejtne3dZ/71WE+KXX7ZxKyaxzaMRGDky2HTx7mlf/d1Fn+vqPx99CouW6q2nqqI6p2DDsbD1pjB8HXGoFlmttoxR75/mjdfdLjyh5oENK8Up50nSvnDOb+GKG7UHu7XWulzdr38MZ5yiE2vsgeCtfquFDz+GXY6Gb2Vwm5JOCdnl5elb9EKXtLCZkeIDYNW3cNO98M8H4LV3Ukk7fowbCwfsDscfAuttpJdxegtRAp6Cua77H4Rjzk7F6U0Nd/X3j46AP5yXmSfutRnVi5IfeBT+cB3MebWwLJVNNoCfHgv/dZieHBPNKUlpdqy96ApdcjqoEGchMNtN/e40+PFJ1nORij/hfvDcc3D5DTD7RT0BZ8OAfjBjCpx1PGyxtaxPKPtRnRVx0W3U09zGTJuh8SkiJ1M+SlZYn5U/5Mrmva+TLxobtfRTx5pGfdxwNyQD4qyendkbHvg3fLVES4vGJn1ug7y+/aFemx6y1nmbElSRgXD3/bDlvnDKr3VxC0Vy/95rZnL5cAFc9DeYuA9ccDHEI3of9kSAtuEtBqmGOa/pPeUarb6pa1J/P/i0Vl3TSC6r85oScNxpMOskmPNKSoqavczSqtfI5+rvdz+C48+FWcfD8tVadW4tHiHi4umXoaExdY+KPVTf6xvgqZf1sDUDMR7Sps85F8KUw+GexzXJTXWdoD3Zlq+E2x+GbQ+CK66GSL8eUaLKrCJo1bfsoW3+7qAdv0sD3iAJw8F76PdBKZ//+RI++0xI5SuqqGzVOa+niv2bc0zO/LRtYZ31UvXjPJKHtM171vl6m+aPP08RJST7v9mlk+LWJhHqe6vXwHl/hN2Phm+W67YC1eCkjmGb6EAolP63vxST17ew1ob3PxFuuCd9k8LW/shusuYw/U3IDqRKNX7gSZhxDKxu0Euj7Hh574A+FXOY83r3SokbT4PpA2deCL//W3oGYzxh9TuZyiiMW5syqven/Q6uvlZrHR21x3qJwTwFsxQpkOjmwyW+k8oaYck0230HXdPc3pfMZJspCfLSPJ3RlbCksrKtV3+jy0slfGmi5jt77yznCRHjST0gTz4bLrk2RXBDFGPf21LdaBJmgIZkq+Yn58L0I+G75doW95ddsq8jWyqpjYQxYy7S1XOqq1KESLtnoXRtI+RrQ5kJ6tyX34b/PlcmIn9p6RxHiPxkD1v+hoSQ/Lln4X+v16v3THpt0ooUGA98ImmFUJOpe6omh59dBAs+gEg31/zrZCyR7ZJDadsmmzfyuri7etcZ8GzpRhi5Lmy/hXxmTW9mEHtqojWiE1KGY94HsHhp5ob+cSkWuddOkl4pa8GjA+GyP8Ffb9dkjcfTUzJNKSdbqhtJaYe0FJnU+fM+hMNP1buMJNrhGvUkYh288zpcflNqxV7G/QqncsaNtpEMcLopE0Rd/80PwjNPyeYWBUjJUCg1aWY7VNuqv41NqSw5pcJfdYv0I5mZcafOGzFEpw6PHpG5A4zZclmZONffpU2yNjkLywMZHA7Kdf+qa/rSdUhIuGe/XbXzJuT7n8Lzr+tdWCJiExpbVtnAGAJYTjw1ELccDxuOg2SDaAd1uuLL2ZelNvhrTYyz6rsNWwsmbQ7DBmnV94358MF/rN+RAWjI/vgL8Odr4dRTIP5d2zzHnjZQA3/6Z2qSyig/JfH0MSNhyiTo00vvbvPki+mRBhvqs0v/AVOnFRaiUeevOwIGDMgko92muu7jD9I+hupqaFyqqwQZqd3aZ7lfvzgBzj4V+kR12Oiqa+CcKyAaTs8PUAP+mVdkc8XKdcp96f8giOify2tlhNZM4kUj7DkFflalVzWZMINRhz/4FBZ8CuuPkyopYp8/87L+v78AhcI+07RkiEs+eigC51ymCWoTyRCkthou+Cn88FAYNFj8o0p6r9bbL59xIXz8RTrZTZz713/RFVkHDdKLWYqB+u1oFTR8A488oz/zSzPzmyceApeeB3X9ab3wZ5+FA0+BZbLBYcKym43zbfGnMGxodoPPTI5Tt4GH/wF12erFh6y8/agUsqiFbxbpBT72swhZ+7RdcCpE66BpBfRSptPhmui21mI0jsrV2FtNcSOsA8s9JyXAvtB3UtnDs98aYb31YasJ2vttBp5ZbBKLwYvzYP1Ndby1qgZWLoFX39Vt2MQwTh7PPm+WNnrDu29qwtobLRqbs7YGHv4bTJuptwtW2oMJdVRFYNbe2rSYfpTe88wQT5FKSaVvl8Mt98FPTtUlq4uBt8KrFj54Ty/eCfky18xvTdgA/vpbPTy835CFITvNgEt/DsecI7uyWIRRJsuqepj/CQwbnZ1FZnLcahOoGw7xhdoHkrXPzelbQscDMgpNmLOhEW5/FI48FGoG69hRv34w+3o9ORg/gwlTbrGRvoaKkWQpmBLPC4XLwUSX14WSONOrkpJmvC1+amHWNE30oOSWJ+fCUd8XUtfC6y/B0mXpEtYmxabjtdruoRbuekJ+J5JS88PiFb74dE3ypoXakeVXv1uWwtDhcOflsMWBevAaTcCozbc/Bj85Pt2MKASeZhHV0QVI+RMMPJUdOGSm1lBUX6qEhMmwrpB78D5aRX/rQ999jetNMDbeUCIPvYL7YEiqTKFFH8HAWmiOZQ4uT/uIplaceacl9FJYZUosa8n8vppUv38mXHEz7LQ17LKd3npq55kyiiXr0HsNywRSeQtdDFeXA19bn3kIIvoSMebHVBLRw7J4T0nhc69I9zSbQahswNgK2fEkKkkkFhHsv1U7kb4Q+1bCU43w1Fz9HXMjzS4p642Gk46E+FJtbwbdUEWslmUwbnM4cm+45s5UWMh4sd98HxZ+ASNHQWxNERcvqVCLJegSRC6FjcZqCZ7mrAxBJKnXsT97M7z1UeaKvI3WgyFDdZ/CWVasmYnylbdhk+kwoH+qso8NLxwW1XXw9t1TV88Jt8CgIbDBGHj1bQmpJdPvtYL6nzouu0Enymy2od4Ce+dJmvh9h+ha8Up7ixZR+qpMYLi6yIqjZyW6me++sIheETDq+/iN9AB44z1LPZZB+PFn8NF/YKMNtaT2nDa+m2AmiH2naQlhCj80rYQFIjGTVrEJ9edeU6FqgFaHA/Pl7T7G4KDdNdHtUF9IVNRPFNHH6lV3xaIxT+670jSyOceSLdB/AEyZEvCFJlkKWoCxp9patkofufDAbNh3P33vPS2pFxyxJ7z8lq4nF5T0YiIX6r4tXwnPvqKPC4Cxo+HIfeFnP9AFNxKru36TzE6GGaafWl6OVr3N/2jM+w99J1cEPAlSJ7a1b3WUKQU99y0IDYGV38JrsijAVtsV6b43GrbaTBs4nkSK6Oy05TJ4/Tdt/PcKu5GePd8C645KecBNF42U/eY7/ZTaVM8hj26Wq0iER/aY3gPdfyRzldYK+I1QkUUhvZTelXDi0bD9RAntRVMJMwatpbcSqbi5SWxa8AVc+GfY5gCY9w6E+1RceM08vffltaCacfM7t0/dA5PppqSxyagyMIP8unvgq8/hhntTFWGTVn02hT2nQvVArQKagRaXTQODUBUt0P4RVdgbwPb2lxZi8eDqMeWGZI7Df23eBBiH2ip44FrYe5q+1yZhxhA6YlUAMisGY9be9+o5fPw57HkcfP21TkKqwKSZ93x5MR5aiS4fmst+1///SoAaCMk1sPkEvRglaWVQGdI/9xpsuC2cdpF+nwiw5Wft4vPaJqCul97IIAiLvimMl57jLaLDWMZ+tbPwFPr1aXtN+fbURvckcURnqEX6Wkef9Dz/fLAdjEGHWZyzxlf6SU18yjwY3B8evBbuvRr22hn6901PgTXP1K7yC6mCk8o8WfiN3tRCaXcVJNWNIfKe3+NOQBzd/PND8VFWVZJDDpPRNkjbzR8sSHe0IVK7vjFTaBpVetQwybBbk8pdT8b1hovDB6cKFNqpsv9+EX6ZZeshG96qsppUko7ZlBArs2udEXqVXKHr1W3U5AhnQeq3Mvol69Ib18Drr1v7zgmpJm4IfQZYEYgcUG2ZSdFPspBUyKmulhwF39JfL6NOfmO/mbDfDPjic21ivfCGTnp6+wMd7svGX5MOe99suGSprilX7FZVJQjD0dXAx/JZ2i3IRvQvJXHme5VGdO+BxrRUvuwfAfngWTLAPBU+ATN2hN5DUjuTYiaPfjpG/PaHqckjLh7s516HV1+BrbfTnvWqAMJ5RK6CluXw19tSfcEK6Y0ZBd9btw2hIVmXOHQt/dYvfE1bH36qw2le3F3+Z1bitbTAzsdoH4YfEzaAp26BQQH17ez7p65B3aN7/wb9a4Vgvn6q31NSt1c/vao6YpkwkQHyPinDOAKjx8PojWG/WTrysXChJv5zb8Ct98OXX/s0I8mdWLgEvlwE39tAT1AVQnRF8m+CjLsgokdEmr9rEb1i4KnqDTBpIqw7Ej5bmFnqOEgNNSGuWbtKrrX1P72oH/bfVa8I808eaiL4r/+B5+/UGWexlan6bub3vO2cB8AZP4ePPksl9GB573ffEWrWEu99EddsJrf11pZr8Yk7c713Pw7n/ASqqqFFpGkiDtWj4K4bNcm9HAF7hV8Y3vkI3poPu+ycg+hyDZO3gtEbQMtiSb4JgLp/zau1wy0sN1ip3ffdBctWyoIXM5qTsNM2MHaM3gxy5AgYuQ7scyAcsw9MOgTWNGRO3kqye+ZBZRinpnbE20Eed7KkwJox9Aqwb6UR3RvzLVA7GGZMhmvuyFTfM84RtX3wQJ3CqdT2iG+3lORqmD5Ve+T/82V66E79Pe992P0ouO4S2GgTeTRmtEZg1VL45Rnwx1vSSY7lqT7+wJQ6W4y9bXIINlxPL/xY9E16G0bzeH0+nPFr+P25UDUodcNenQOnXyIVdBPpu8uqiaCut67m4gVm82y6vfhbbRBWDSRgPxHprylauEaXgYr0gxefgUNOC25zz53g4Tv15JFYIwt4VsP49aF/H6hfkymxi91GqkwgAeHMuxpE9KTvpMqY8yx4dyGuF7n8/Y78nteIVKXZdTvoPyJzF1WvkkoMagfCef8NR/8iXfIZsr/wJmy1Dxy0F0zfXg/CphadZnvHQ7Dgq1SSjYFJmjlkBmy1nSy8UbZ7EU4kNcjV5FY3FGZOgevvSbf/W/soC1QenQOTJ2lb+pPP4bGnJYvNN8GYyWzyljBqDLSsgKra4D6Y37r3CTj+BBg5XN+zjIQZ67q/vy+MWVc/qz69UgUx7NrtIVl5+PA9sNcsPYF6llESLv+TntTSNDY5R5kxaw/LvTlEGcGMRknx0lVlbKQRXfZTNrdkntSeqqs0O92o71O20rXFFi/NLSVN2EdNDMksmxSaPd6OOhRufRgee06rpmZRhSG7UhdvukcfGW34SG7IOKg/XHqurl3e1kFpQos/OkITPQhmHff8T/ThPz9o5Zr67PSjC4/tNzXDtXcV1ud3PoY7rtG70IwfByOHwVdf65FoL/1V93jvk2GPf+m6ey0tMHcevCR74tv9Nvd0xo5QNyzd11KmMNxcaoXFM8RAkLQ2J36d68RyhhdDb4Y+w2C37UV7zqK3mIowfet0DnVoTY7voj3wN10G49ZNLTM1SFgVT+x93kwoKI3kkVTe/G1XwNpjpNxVG4nuTSKrYcvt4EeH68FencUpGA77Ck8EkLyqSseyD5wOu8/QCS2FEsZrOxpc/kkdNdX61VuPLoUulKl14sGyyCdgx1iFx56FP1wLV96oSZ6hrls7wJz5X/mr/5YJzKh5U8rAhYMMkmxqubmVz8trZVkylpTef9eshVI9mBDa1EkwdLSeILINDm8gNcKQwfDEzTojriWWIjXWIox4PLUhor3hY1hyvdXnvWrgrj/B9OmZ5oJBroEaZJfGV8Glv4Jpk1IZZhm18hK+whPJ9Gv0NJUWXRk2aHfZfOSJSXJRLJ77MPfM8w2shNNPhG0m6H6rScqe9ELyPTOBRMLpy4SjkVQ67VW/gvGbQ6K+Itakm6djuBp4Rdku05z8tLyW/7zng5dF1aBrvvXvqz+ryiJlPG/7NG3o5HOCedsY18M6a8OcO/SGi3Ff/bKIrwCjXXzR7MK6+cbwzL/08tXYMr2RYBDMRBLUb89ssPrrpZ7GoSYKD14HB8+UHV99fWstDCl18uzMM5N4ou6bmswG9kvl/BvEYtmldTFHcyzVb2Tie+AamLK1JnvCyooLR9JLSUH68zMazF8ugBOPyz5xliEMh6XSQLDMyiC6L0Nurtjp2coElC08lVy2G95jiiZjS4CUUTZlbQ3MnJpKksmHsOzvNqgv/OtquP+venD6pXlQ8cX114XLzoGX7oJtttQDMho0ICVSOnKoPl+puabPigTqdfRw7QX3h8OUylpXDXdcDbdeptfo231rLeskxLEzz8aMgsvPhX/frGvaJxrT67OpETV4UOre5ZPaQYc5b/hgsf2TqUVJw4fAk7fAJWfqvrT2Le4raGlpJcoUOHAGzL0bTjpOykeXvyTHWoim7PPX5bOE3xFHNkktKXRmEfuzwBSrZnTFwJSL+nYpPPyMZE2RWf5pwvqw7dbFb9bXWoCyn/buvjoPnnheL6X8YpEuh6xs3RGDdb30XXfQ4bvaQcAqvbVxthVWSemfIsX9s3U2WMiKL6u/Z0zWmyAE2aKtfeuvp/IX3tAZfG/Oh88X6QU6iixKiirCKTNktx300WcosDKz5rwXBqyCpd/oAhwt8eLT8s33lXa191SpqGN551t/s58u3PnUXHh6Lrz/ifaw1zfqiVFpGmPXhu03h912hHFSbKLCNnEwnHwI2Mdwtliim014foVe6ReryP3UpShDzk2oWnSOfFsdN6YcVKi3BIhlqyDvjoYl9lwln9frsFPBWzSr7/TJ8iTXSOpTjna8TRciuuBEax8aIdakJaO3IKeX9DEh/WvJQRaZPGnPTqoG9XKP/JMUOn4fMb9jUryapG8mEF8j97cxlTpbATa5DcPJHwNXGc4WS3STXTNJVPiKCrHZMCudsiFU4EaM+WDU4RDpRM72eUF9J3v11UiBbSWxSlGbPljXm4gX179897NQ5Ot/0tpgsfUZiUpg/y9cufuumWTgTYH3ipbokLZNU7U0sl6lbNPkkB/+pJRygV38psJhuDgP2NIEkoJITh7SGqW2GXjMmj0cegBaN1Po7o4UiSxZtZUIw8VHUkt8siOfdDYT5H207knq4OBQAjBcvF9ec/o88xHXzBrPSa3osJPqDg7dDqO2fyhhNS/TIJvaTi6iW/H0qJR/fsj6EQcHh+6D4eC9Em/IGzAsRBU3KsHtRZzj4ODQeTAJbHfK+7ypCoWQ1lQoe14qWDj13cGh+2AKec0D3jBqe76TchLdUt8j4n2/Q/7liO7g0D0w0vuftrc9l31OEWq4IfYtko1TOUmEDg7lA9tnVpTQzUt0mSmMl+898cBTiLrg4ODQoYgL2f9PirdGsmXC+VGMY8189+89JyfBwaGkYJJ8r2nLiYXCOAEekJh6xNnqDg5dBjt2/u9UEe/CUBDRfU65euAf1o87ODh0PgzXrhHHeCRXbrsfxcbEzY9dKztOV1xBCgeHEoQRsiuAm+SzonxkbSF6RLZmvafQGJ6Dg0O7YMzmfwJLipXmFEN0X6PqRy+3Stk4ODh0HkxpjT+2dS/dtpDUzC6vAk9IG06qOzh0DkyNnfuAD9qamVoU0S2pbsJrF/neOzg4dCxMnfaLbZ4Vo7bTDrU7Luc+BcxxUt3BoVNgePYI8Fp7eFY00QOk+m987x0cHDoGxh7/TdqHRUpz2ulIM7PNE1I83kl1B4eOg+HXQ1KcNWMr5GLQZinsqxQ7Req/u+KRDg7tR9I6tpZ91SL5qsjkQntJaQrIz5GZx0l1B4f2wwjM22ySt6fBdtnVllRXHZsg9avCPasYp4NDh8JI8ibh1AKT195WaU4HqdnGlngbuN5JdQeHdsHw6SrgPx1V0andUtfap01hiKxZ7++kuoND0TBl274Gxusd7nJvzFAoOspxZjq4WPZpc1LdwaF4mG3PzgGWtzXdNQgdInFFqpsNHsKSHrtZJe7A6uDQSTBceQGYbAvL9kpzOjgUZmaeFtnd0f+5g4NDMAxHFLFP6QzOdAjRrRnHzErPiGPOVaFxcMgPw5srpYRzpCOlOR3tLPM55gYA7wLD3HJWB4esMP6tBWLuNnSUA85GZ5DPdPw74NRia1s5OPQwGL6cJGXaOswBZ6NDie5T4aPAXbKVU9R54R0cMhATbvxd1oxEO1plN+jwOLeo71iTyCDgLWC4U+EdHFph0lz/A2wOrJHPPGne0UTvcNJZHTQqyVLgBKfCOzi0ImmR+gfAKuvzDic5nSVdA1T4h4A/yd+xzvhNB4cyguHF72TVZ6ep7AadlqJqqfAmkSYq62onukQahx4MM/afB6bKZ52msht0ai66z15PSP7uK0CNtcrNwaGnwJiuK4AtpWx666KVziI5ne0Y89nrSqIr6p/cEetrHRzKEMYBd5yQPNIVJKcrPODWBZhQwk3A1c5ed+hhMOP/91K6udPtchtdojoH2OshqSA72dnrDj0AZow/CuxpkbxT7XIbXWYjB9jrI8ReH+VqzTlUMAzJPwK2tZafdonKbtBl5PLZ6+rCFwEHSsmcpFvl5lCBMAJsFXAAsKyrnG9+dKkUDYivzwWOtZxzjuwOlYKkVUjicOCdrrbLbXSnumycE7cBv3DOOYcKg1HZfwQ8bI/vriY53UF030Uasl8kmXNVUrjCwaGc0WJlvl0t47pbhVi3JawEeOLjstLtEGsCcHAoN7QIsa8Fju8OD3sQujUzzUd2Q3il5uzuyO5QhjAkvwc4yHK8dSvJ6W6ikxl2UzekN/B/wI6O7A5lBDNW1djdx5Li3U5ySiF2HbCstR7YG3jZOegcygSG5E8B+1tjtiRITikQnUyyhyWpYKZs8eTI7lDKMI63Z4B9peZblyfE5ENJEJ3ghJrvgOlOsjuUMGJikytJvhewursSYvKhZIhOcNloRfYZwHNCdhd6cygVGEn+mJC8vlRJTqkRnUyyGzV+D3FyuDi7QykgZnnXZ4m6XrIkpxSJTrDNXi+ezNut5AOXLuvQ1UhajrdrZa1GS6mTnFIlOsFkVzf4MNlONmrHJx0cugBmvJlMzuMt/pQ0ySmFOHo+BCTVqJt6tizgxy1xdegC2DUTTpV07UipJMMUgpInOtnTZQ+X/d1qXfEKh06EUdVXAkcBD5RKWmsxKAuik052rHDb9rL6bR2XRefQCTBj6kPgUOBNf6i3HEhOOam8WVa9vSipss/4Z1kHh3YgadVMeFTGWNmSnHIiOsFkV+r6l8BuwJ/lfchVmHVoB+IyhtRYulhqvC2V92VJcspJdbfhU+PD1uKBY8Ur38ep8g5tgBkzy4ATgTv9nnXKkOSUK9ENfE46M+NuJk66razZuaw0F4cuhyFxWLIwfyh2edk53bKhrAlg3Xg7keEtKSN9lZA/7PLkHXIgJmMkLPHxaRbJY5VAcspdohsEqPJmhp4lhB/tpLuDD7YU/wT4b+BxX76Gh3InOZVCdDLJbqvyw4DLgCPkf852d7DHwLXAmWKXV4yq7kfFEN3AR3h7j7dDgf8V6W7P5g49B3FrpyAlxU+XBBj8+wFWEsmpxIHue0B2qOR2YGvgGssmc4tjegaSvuzJK2UsPBAUkq00klOJEt1GDum+q8RIt5L3MeuBO1QO7MQXZE/ys+SVSpfiNip+YAfY7iZXvgo4RTaPGCL/dznzlQP7WS4ELgT+KuSP+Fc/VjLJ6QlEN8gh3UcB51o1uJNWOSuH8oNthzcCf5Gw2RLfRO+h0glu0GOITm7prrAl8CtgP3mfsGZ/h9KHTXBksZOS4u/K+4y6gz2F5PQ0ohvkIfw04BzJn8cRvuThJ/hDIsFtO7xHqelB6JFENwhItMEKvc0EzgB2MV+3ilz06PtWAggyrx4B/iAVWZH/JSst8aWtcAM22H63B8h04KeyisnATpt06Dok5Iha7++XcNkz8llFLELpaDiiC3xkJ0Dl2x44WQoC9pbPjLrvpHznwZ50jQRfCdwhXvTX5LNwT4iHtxVucPqQhfD2YFsfOEbKCq1rfc9J+Y6FX3orfAzcJMdn8lkGwXEkz4Ajeg4E2PD2gOorW/AcI3a8kTYJy5Z3pC8OCcv2NmOzGfg38A/ZaXeNfO5s8CLgiF4AAgjvX/q6qeTSK7V+I+tzR/r8yHaP3pHCD0pFf9/6PGqd48ERPD8c0YtAlrCcLVWqgJ1kb+w9gDH26b6lsj313id9NdJtfCJS+24Jj/l9ID0+TNZW9NTB1i4E2PFBUr5OCmDsKzH5cb5zzHLISie+TewgzeY9WQf+IPCCbG9kkCG9cQRvEyp1cHUZskh5fM6hasm8200W1Ki/+/maSlh7xNtHOSHpO4KIvVw85U8As6W6qj1BRn2TgwdH7vah3AZSSaNA0iuMBCaJmr8DMF6ce37Y0qyUJgA/ocnhh1gh9vaLEut+BVjs+44jdyejuwdMxSIL6UNZas+PkKKW28g66fESuqvO1nzA3nOhLK/+/we1FfTe/+q/jiA0AQsAdfWvCqnfDiB22Cr5lXTk7nw4oncBAmz6fMSvkko4yq7fRDz5GwJrA8OBXl3W+WCsAb4GvgA+EK/4u1JU8YsADSbkC4elXa8jd+fDEb0bkIf4yRwbUFRLDbwRov6PlmW2ivxDgUHAAKlrXytHlajG2cJ7CbGRm0UiNwKrxJb+TqTxYtko4wtZ271Iln1m26s+Yl2LI3YJwBG9BJCF+H57PMP7nAWK0DUi9Wvlb0N2fzgrFkDyBvm7kBJbtl0eZLfri3HE7nY4opcw8kwA+J5foPRsB4Lscdtud4QuIziilzECJgKKcMJlNJfnvSOyg4ODQynj/wMAAP//Pud4RbJ7N8IAAAAASUVORK5CYII=';\\n  var COMPOSER_URL = 'http://localhost:3001';\\n  var YELLOW = '#ffd600';\\n  var BLACK = '#0a0a0a';\\n  var SV_VERSION = 'v9';\\n  var hostSelectorUsed = '—';\\n\\n  function setChip(extra) {\\n    var chip = document.getElementById('sv-debug-chip');\\n    if (!chip) {\\n      chip = document.createElement('div');\\n      chip.id = 'sv-debug-chip';\\n      chip.style.cssText = 'position:fixed;bottom:8px;left:8px;background:#0a0a0a;color:#ffd600;font-family:Rubik,sans-serif;font-size:10px;font-weight:700;padding:3px 8px;border-radius:999px;z-index:9998;opacity:0.6;pointer-events:none;letter-spacing:0.5px;max-width:360px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;';\\n      document.body.appendChild(chip);\\n    }\\n    chip.textContent = 'SV ' + SV_VERSION + (extra ? ': ' + extra : '');\\n  }\\n\\n  function setFavicon() {\\n    document.querySelectorAll('link[rel*=\\"icon\\"]').forEach(function (l) { l.parentNode.removeChild(l); });\\n    var link = document.createElement('link'); link.rel = 'icon'; link.type = 'image/png'; link.href = LOGO_URI;\\n    document.head.appendChild(link);\\n  }\\n\\n  function brand() {\\n    var img = document.querySelector('.navbar-brand img') || document.querySelector('.navbar img');\\n    if (img && !img.dataset.svBranded) {\\n      img.dataset.svBranded = '1';\\n      img.src = LOGO_URI;\\n      img.removeAttribute('width'); img.removeAttribute('height');\\n      img.style.cssText = 'width:32px !important;height:32px !important;border-radius:0 !important;object-fit:contain !important;display:inline-block !important;vertical-align:middle !important;margin:0 !important;';\\n      var parent = img.parentNode;\\n      if (parent && !parent.querySelector('.sv-brand-text')) {\\n        var span = document.createElement('span');\\n        span.className = 'sv-brand-text';\\n        span.textContent = 'STREET VOICES';\\n        span.style.cssText = 'font-family:Rubik,Helvetica,Arial,sans-serif !important;font-size:16px !important;line-height:32px !important;font-weight:700 !important;letter-spacing:0.5px !important;text-transform:uppercase !important;color:#0a0a0a !important;display:inline-block !important;vertical-align:middle !important;margin-left:10px !important;';\\n        if (img.nextSibling) parent.insertBefore(span, img.nextSibling);\\n        else parent.appendChild(span);\\n      }\\n      var item = img.closest('a, .navbar-item') || parent;\\n      if (item) { item.style.display = 'flex'; item.style.alignItems = 'center'; item.style.gap = '0'; }\\n    }\\n    document.querySelectorAll('.navbar-brand img').forEach(function (i, idx) { if (idx > 0) i.style.display = 'none'; });\\n    document.querySelectorAll('.navbar-brand .navbar-item, .navbar-brand a').forEach(function (el) {\\n      Array.from(el.childNodes).forEach(function (n) {\\n        if (n.nodeType === 3 && /^\\\\s*listmonk\\\\s*$/i.test(n.textContent)) n.textContent = '';\\n      });\\n    });\\n    if (/listmonk/i.test(document.title) && !/Street Voices/i.test(document.title)) {\\n      document.title = document.title.replace(/listmonk/gi, 'Street Voices');\\n    }\\n  }\\n\\n  function ensureAIFab() {\\n    var onCampaigns = /\\\\/admin\\\\/campaigns/i.test(location.hash + ' ' + location.pathname);\\n    var existing = document.getElementById('sv-ai-fab');\\n    if (!onCampaigns) { if (existing) existing.style.display = 'none'; return; }\\n    if (existing) { existing.style.display = 'flex'; return; }\\n    var fab = document.createElement('a');\\n    fab.id = 'sv-ai-fab';\\n    fab.href = COMPOSER_URL; fab.target = '_blank'; fab.rel = 'noopener';\\n    fab.innerHTML = '<span style=\\"font-size:18px;line-height:1;\\">✨</span><span style=\\"font-weight:700;font-size:13px;letter-spacing:0.4px;text-transform:uppercase;\\">AI Compose</span>';\\n    fab.style.cssText = 'position:fixed;bottom:24px;right:24px;z-index:9999;display:flex;align-items:center;gap:10px;padding:14px 20px;background:' + YELLOW + ';color:' + BLACK + ';border-radius:999px;text-decoration:none;font-family:Rubik,Helvetica,Arial,sans-serif;box-shadow:0 6px 20px rgba(255,214,0,0.45),0 2px 6px rgba(0,0,0,0.1);cursor:pointer;';\\n    document.body.appendChild(fab);\\n  }\\n\\n  function isOnDashboard() {\\n    var p = location.pathname.replace(/\\\\/$/, '');\\n    if (p !== '/admin' && !/\\\\/admin\\\\/dashboard$/.test(p)) return false;\\n    var h = location.hash;\\n    return h === '' || h === '#' || h === '#/' || h === '#/dashboard';\\n  }\\n\\n  function fmt(n) { return Number(n || 0).toLocaleString('en-CA'); }\\n  async function fetchJSON(url) {\\n    var r = await fetch(url, { credentials: 'include' });\\n    if (!r.ok) throw new Error('HTTP ' + r.status);\\n    return await r.json();\\n  }\\n  function cardShell(title, contentHtml) {\\n    return '<div style=\\"background:#fff;border:1px solid #eeeae0;border-radius:16px;padding:20px;box-shadow:0 1px 3px rgba(0,0,0,0.04),0 4px 12px rgba(0,0,0,0.04);font-family:Rubik,sans-serif;min-width:0;height:100%;display:flex;flex-direction:column;\\">'\\n      + '<div style=\\"display:flex;align-items:center;gap:8px;margin-bottom:14px;flex-shrink:0;\\">'\\n        + '<span style=\\"display:inline-block;width:6px;height:18px;background:' + YELLOW + ';border-radius:3px;\\"></span>'\\n        + '<h3 style=\\"margin:0;font-size:13px;font-weight:700;color:#777;text-transform:uppercase;letter-spacing:0.7px;\\">' + title + '</h3>'\\n      + '</div>'\\n      + '<div style=\\"flex:1;min-height:0;\\">' + contentHtml + '</div>'\\n    + '</div>';\\n  }\\n\\n  async function overviewContent() {\\n    try {\\n      var data = await fetchJSON('/api/dashboard/counts');\\n      var d = data.data || {};\\n      var L = d.lists || {}; var S = d.subscribers || {}; var C = d.campaigns || {}; var M = d.messages || 0;\\n      var statuses = C.by_status || {};\\n      var statusLine = Object.keys(statuses).map(function (k) { return fmt(statuses[k]) + ' ' + k; }).join(' · ') || '—';\\n      var metric = function (icon, value, label, sub, noBorder) {\\n        return '<div style=\\"padding:12px 0;' + (noBorder ? '' : 'border-bottom:1px solid #eeeae0;') + '\\">'\\n          + '<div style=\\"display:flex;align-items:center;gap:14px;\\">'\\n            + '<div style=\\"width:36px;height:36px;background:#fffbe6;border:1px solid ' + YELLOW + ';border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:16px;flex-shrink:0;\\">' + icon + '</div>'\\n            + '<div style=\\"flex:1;min-width:0;\\">'\\n              + '<div style=\\"display:flex;align-items:baseline;justify-content:space-between;gap:8px;\\">'\\n                + '<div style=\\"font-size:24px;font-weight:800;color:#0a0a0a;letter-spacing:-0.5px;line-height:1;\\">' + value + '</div>'\\n                + (sub ? '<div style=\\"font-size:10px;color:#999;text-align:right;font-weight:500;\\">' + sub + '</div>' : '')\\n              + '</div>'\\n              + '<div style=\\"font-size:10px;color:#777;text-transform:uppercase;letter-spacing:0.5px;font-weight:600;margin-top:4px;\\">' + label + '</div>'\\n            + '</div>'\\n          + '</div>'\\n        + '</div>';\\n      };\\n      return metric('📋', fmt(L.total), 'Lists', fmt(L.public || 0) + ' public · ' + fmt(L.private || 0) + ' private')\\n        + metric('👥', fmt(S.total), 'Subscribers', fmt(S.blocklisted || 0) + ' blocklisted · ' + fmt(S.orphans || 0) + ' orphans')\\n        + metric('🚀', fmt(C.total), 'Campaigns', statusLine)\\n        + metric('📧', fmt(M), 'Messages sent', '', true);\\n    } catch (e) {\\n      return '<div style=\\"color:#b22020;font-size:12px;\\">Could not load: ' + e.message + '</div>';\\n    }\\n  }\\n\\n  function quickActionsContent() {\\n    var btn = function (icon, label, href, primary, external) {\\n      var bg = primary ? YELLOW : '#fff';\\n      var color = primary ? BLACK : '#2d2d2d';\\n      var border = primary ? YELLOW : '#eeeae0';\\n      var target = external ? '_blank' : '_self';\\n      return '<a href=\\"' + href + '\\" target=\\"' + target + '\\" style=\\"display:flex;align-items:center;gap:12px;padding:13px 16px;background:' + bg + ';color:' + color + ';border:1px solid ' + border + ';border-radius:12px;text-decoration:none;font-weight:600;font-size:14px;\\">'\\n        + '<span style=\\"font-size:18px;width:22px;text-align:center;\\">' + icon + '</span>'\\n        + '<span>' + label + '</span></a>';\\n    };\\n    return '<div style=\\"display:flex;flex-direction:column;gap:10px;\\">'\\n      + btn('✨', 'Open AI Composer', COMPOSER_URL, true, true)\\n      + btn('+', 'New campaign', '/admin/campaigns/new', false, false)\\n      + btn('👤', 'Add subscriber', '/admin/subscribers/new', false, false)\\n      + btn('📋', 'Manage lists', '/admin/lists', false, false)\\n      + '</div>';\\n  }\\n\\n  async function lastWeekContent() {\\n    try {\\n      var data = await fetchJSON('/api/campaigns?per_page=100');\\n      var camps = (data && data.data && data.data.results) || [];\\n      var sevenDaysAgo = Date.now() - 7*24*3600*1000;\\n      var recent = camps.filter(function (c) { var d = c.started_at || c.updated_at; return d && new Date(d).getTime() > sevenDaysAgo; });\\n      var totals = recent.reduce(function (a, c) { a.sent += c.sent || 0; a.views += c.views || 0; a.clicks += c.clicks || 0; return a; }, { sent: 0, views: 0, clicks: 0 });\\n      var openRate = totals.sent ? (100 * totals.views / totals.sent).toFixed(1) + '%' : '—';\\n      var clickRate = totals.sent ? (100 * totals.clicks / totals.sent).toFixed(1) + '%' : '—';\\n      var stat = function (label, value, sub) {\\n        return '<div style=\\"text-align:center;padding:14px 8px;\\">'\\n          + '<div style=\\"font-size:30px;font-weight:800;color:#0a0a0a;letter-spacing:-0.5px;line-height:1.1;\\">' + value + '</div>'\\n          + '<div style=\\"font-size:10px;color:#777;text-transform:uppercase;letter-spacing:0.5px;font-weight:600;margin-top:4px;\\">' + label + '</div>'\\n          + (sub ? '<div style=\\"font-size:12px;color:#aaa;margin-top:3px;font-weight:500;\\">' + sub + '</div>' : '')\\n        + '</div>';\\n      };\\n      return '<div style=\\"display:grid;grid-template-columns:1fr 1fr 1fr;gap:4px;\\">' + stat('Sent', fmt(totals.sent)) + stat('Opens', fmt(totals.views), openRate) + stat('Clicks', fmt(totals.clicks), clickRate) + '</div>'\\n        + '<div style=\\"margin-top:16px;padding-top:14px;border-top:1px solid #eeeae0;text-align:center;font-size:11px;color:#aaa;\\">across ' + recent.length + ' campaign' + (recent.length === 1 ? '' : 's') + ' in the last 7 days</div>';\\n    } catch (e) {\\n      return '<div style=\\"color:#b22020;font-size:12px;\\">Could not load: ' + e.message + '</div>';\\n    }\\n  }\\n\\n  function ensureHideStyle() {\\n    if (document.getElementById('sv-hide-style')) return;\\n    var style = document.createElement('style');\\n    style.id = 'sv-hide-style';\\n    style.textContent = '#sv-dashboard ~ .tile.is-ancestor,'\\n      + ' #sv-dashboard ~ .columns,'\\n      + ' #sv-dashboard ~ .dashboard,'\\n      + ' #sv-dashboard ~ .box,'\\n      + ' #sv-dashboard ~ h1,'\\n      + ' #sv-dashboard ~ h4 { display: none !important; }';\\n    document.head.appendChild(style);\\n  }\\n\\n  // Find Listmonk's dashboard host container. Tries several selectors.\\n  function findDashboardHost() {\\n    var attempts = [\\n      ['.dashboard parent',             function () { var d = document.querySelector('.dashboard'); return d ? d.parentNode : null; }],\\n      ['main.column',                    function () { return document.querySelector('main.column'); }],\\n      ['section.column not narrow',     function () { return document.querySelector('section.column:not(.is-2):not(.is-3):not(.is-4):not(.is-narrow)'); }],\\n      ['.column not narrow',            function () { return document.querySelector('.column:not(.is-2):not(.is-3):not(.is-4):not(.is-narrow)'); }],\\n      ['section.section container',     function () { return document.querySelector('section.section > .container, section.section > div'); }],\\n      ['section.section',               function () { return document.querySelector('section.section'); }],\\n      ['main',                          function () { return document.querySelector('main'); }],\\n    ];\\n    for (var i = 0; i < attempts.length; i++) {\\n      var el = null;\\n      try { el = attempts[i][1](); } catch {}\\n      if (el) {\\n        hostSelectorUsed = attempts[i][0];\\n        return el;\\n      }\\n    }\\n    hostSelectorUsed = 'NONE FOUND';\\n    return null;\\n  }\\n\\n  function tryRelocateChart() {\\n    var target = document.getElementById('sv-cell-campaigns');\\n    if (!target) return;\\n    var slot = target.querySelector('.sv-chart-slot');\\n    if (!slot) return;\\n    if (slot.querySelector('canvas, svg.chartjs-render-monitor, .b-tabs')) return;\\n\\n    var candidates = document.querySelectorAll('h4, h3, .title, .subtitle, header');\\n    var chartHeader = null;\\n    for (var i = 0; i < candidates.length; i++) {\\n      var txt = (candidates[i].textContent || '').trim().toLowerCase();\\n      if (txt === 'campaign views') { chartHeader = candidates[i]; break; }\\n    }\\n    if (!chartHeader) return;\\n\\n    var container = chartHeader;\\n    while (container && container.parentNode) {\\n      if (container.querySelector && container.querySelector('canvas, svg')) break;\\n      container = container.parentNode;\\n    }\\n    if (!container || container === document.body || container.id === 'sv-dashboard') return;\\n\\n    slot.appendChild(container);\\n  }\\n\\n  async function ensureWidgets() {\\n    ensureHideStyle();\\n    if (!isOnDashboard()) {\\n      document.body.classList.remove('sv-on-dashboard');\\n      var ex = document.getElementById('sv-dashboard');\\n      if (ex) ex.remove();\\n      setChip('off dashboard');\\n      return;\\n    }\\n    document.body.classList.add('sv-on-dashboard');\\n\\n    if (document.getElementById('sv-dashboard')) {\\n      tryRelocateChart();\\n      setChip('host=' + hostSelectorUsed + ' · widget OK');\\n      return;\\n    }\\n\\n    var host = findDashboardHost();\\n    if (!host) {\\n      setChip('NO HOST FOUND');\\n      return;\\n    }\\n\\n    var wrap = document.createElement('div');\\n    wrap.id = 'sv-dashboard';\\n    wrap.style.cssText = 'display:grid;grid-template-columns:1fr 1fr;grid-template-rows:auto auto;gap:20px;width:100%;padding:8px 0;';\\n\\n    var todayDate = new Date().toLocaleDateString('en-CA', { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric' });\\n    var heading = document.createElement('div');\\n    heading.style.cssText = 'grid-column: 1 / -1; margin: 0 0 4px 0; font-family: Rubik, sans-serif;';\\n    heading.innerHTML = '<div style=\\"font-size:12px;color:#777;text-transform:uppercase;letter-spacing:0.7px;font-weight:600;\\">' + todayDate + '</div>'\\n                     + '<h1 style=\\"margin:4px 0 0 0;font-size:28px;font-weight:800;color:#0a0a0a;letter-spacing:-0.5px;\\">Dashboard</h1>';\\n    wrap.appendChild(heading);\\n\\n    var cells = [\\n      { id: 'sv-cell-overview',  title: 'Overview',       loader: overviewContent },\\n      { id: 'sv-cell-actions',   title: 'Quick actions',  html:   quickActionsContent() },\\n      { id: 'sv-cell-campaigns', title: 'Campaign views', html:   '<div class=\\"sv-chart-slot\\" style=\\"display:flex;flex-direction:column;height:100%;min-height:240px;\\"><div style=\\"flex:1;position:relative;margin-top:-4px;\\"><svg viewBox=\\"0 0 400 180\\" preserveAspectRatio=\\"none\\" xmlns=\\"http://www.w3.org/2000/svg\\" style=\\"width:100%;height:180px;\\"><defs><linearGradient id=\\"svChartFill\\" x1=\\"0\\" y1=\\"0\\" x2=\\"0\\" y2=\\"1\\"><stop offset=\\"0%\\" stop-color=\\"#ffd600\\" stop-opacity=\\"0.35\\"/><stop offset=\\"100%\\" stop-color=\\"#ffd600\\" stop-opacity=\\"0\\"/></linearGradient></defs><g stroke=\\"#eeeae0\\" stroke-width=\\"1\\"><line x1=\\"0\\" y1=\\"30\\" x2=\\"400\\" y2=\\"30\\" stroke-dasharray=\\"3 4\\"/><line x1=\\"0\\" y1=\\"75\\" x2=\\"400\\" y2=\\"75\\" stroke-dasharray=\\"3 4\\"/><line x1=\\"0\\" y1=\\"120\\" x2=\\"400\\" y2=\\"120\\" stroke-dasharray=\\"3 4\\"/><line x1=\\"0\\" y1=\\"165\\" x2=\\"400\\" y2=\\"165\\"/></g><path d=\\"M0,140 C60,120 90,90 140,85 S210,110 260,80 S340,50 400,60 L400,180 L0,180 Z\\" fill=\\"url(#svChartFill)\\"/><path d=\\"M0,140 C60,120 90,90 140,85 S210,110 260,80 S340,50 400,60\\" fill=\\"none\\" stroke=\\"#ffd600\\" stroke-width=\\"2\\" opacity=\\"0.55\\"/><g fill=\\"#ffd600\\" opacity=\\"0.7\\"><circle cx=\\"0\\" cy=\\"140\\" r=\\"3\\"/><circle cx=\\"70\\" cy=\\"108\\" r=\\"3\\"/><circle cx=\\"140\\" cy=\\"85\\" r=\\"3\\"/><circle cx=\\"210\\" cy=\\"100\\" r=\\"3\\"/><circle cx=\\"260\\" cy=\\"80\\" r=\\"3\\"/><circle cx=\\"330\\" cy=\\"62\\" r=\\"3\\"/><circle cx=\\"400\\" cy=\\"60\\" r=\\"3\\"/></g></svg></div><div style=\\"text-align:center;padding:14px 8px 4px;border-top:1px dashed #eeeae0;margin-top:6px;\\"><div style=\\"font-size:13px;font-weight:700;color:#0a0a0a;margin-bottom:4px;\\">No campaign views yet</div><div style=\\"font-size:11px;color:#999;line-height:1.5;\\">Send your first campaign to see opens over time here.</div></div></div>' },\\n      { id: 'sv-cell-week',      title: 'Last 7 days',    loader: lastWeekContent },\\n    ];\\n    cells.forEach(function (cell) {\\n      var d = document.createElement('div');\\n      d.id = cell.id;\\n      d.style.cssText = 'min-width:0;';\\n      d.innerHTML = cardShell(cell.title, cell.html || '<div style=\\"color:#777;font-size:12px;\\">Loading…</div>');\\n      wrap.appendChild(d);\\n    });\\n\\n    host.insertBefore(wrap, host.firstChild);\\n\\n    cells.forEach(function (cell) {\\n      if (!cell.loader) return;\\n      cell.loader().then(function (html) {\\n        var s = document.getElementById(cell.id);\\n        if (s) s.innerHTML = cardShell(cell.title, html);\\n      });\\n    });\\n\\n    if (window.innerWidth < 900) wrap.style.gridTemplateColumns = '1fr';\\n\\n    tryRelocateChart();\\n    setChip('host=' + hostSelectorUsed + ' · widget injected');\\n  }\\n\\n  function isBlueish(rgb) {\\n    if (!rgb) return false;\\n    var m = rgb.match(/rgba?\\\\((\\\\d+),\\\\s*(\\\\d+),\\\\s*(\\\\d+)/);\\n    if (!m) return false;\\n    var r = +m[1], g = +m[2], b = +m[3];\\n    return b > 130 && b > r + 30 && b > g + 30 && r < 120;\\n  }\\n  function killBlues() {\\n    document.querySelectorAll('*').forEach(function (el) {\\n      if (el.dataset.svBlueKilled || el.id === 'sv-ai-fab' || el.closest('#sv-dashboard')) return;\\n      var s = window.getComputedStyle(el);\\n      var changed = false;\\n      if (isBlueish(s.backgroundColor)) { el.style.setProperty('background-color', YELLOW, 'important'); el.style.setProperty('color', BLACK, 'important'); changed = true; }\\n      ['Top','Right','Bottom','Left'].forEach(function (side) {\\n        if (isBlueish(s['border' + side + 'Color'])) { el.style.setProperty('border-' + side.toLowerCase() + '-color', YELLOW, 'important'); changed = true; }\\n      });\\n      if (changed) el.dataset.svBlueKilled = '1';\\n    });\\n  }\\n\\n  function run() { setChip(''); setFavicon(); brand(); killBlues(); ensureAIFab(); ensureWidgets(); }\\n  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', run);\\n  else run();\\n  setInterval(run, 1200);\\n  window.addEventListener('hashchange', run);\\n  window.addEventListener('popstate', run);\\n  window.addEventListener('resize', function () {\\n    var wrap = document.getElementById('sv-dashboard');\\n    if (wrap) wrap.style.gridTemplateColumns = window.innerWidth < 900 ? '1fr' : '1fr 1fr';\\n  });\\n})();\\n"	2026-04-17 17:32:05.899219+00
privacy.unsubscribe_header	true	2026-04-17 17:32:05.899219+00
app.send_optin_confirmation	true	2026-04-17 17:32:05.899219+00
appearance.admin.custom_css	"@import url('https://fonts.googleapis.com/css2?family=Rubik:wght@400;500;600;700;900&display=swap');\\n\\n/* ============ BASE ============ */\\nhtml, body {\\n  background-color: #faf8f3 !important;\\n  font-family: 'Rubik', 'Helvetica Neue', Arial, sans-serif !important;\\n  color: #2d2d2d !important;\\n  -webkit-font-smoothing: antialiased;\\n}\\n\\nbody, .navbar, .button, .input, .textarea, .select, .select select,\\n.menu, .field, .label, .title, .subtitle, .tag, .tabs,\\n.b-table, .table, .modal-card, .dropdown-content, .breadcrumb {\\n  font-family: 'Rubik', 'Helvetica Neue', Arial, sans-serif !important;\\n}\\n\\n/* ============ TYPOGRAPHY ============ */\\n.title { font-weight: 700 !important; letter-spacing: -0.5px !important; color: #0a0a0a !important; }\\n.title.is-1, h1.title { font-size: 32px !important; line-height: 1.2 !important; }\\n.title.is-2 { font-size: 26px !important; }\\n.title.is-4, h4.title { font-size: 18px !important; }\\n.subtitle { color: #777 !important; font-weight: 400 !important; }\\n\\n/* ============ NAVBAR ============ */\\n.navbar {\\n  background-color: #ffffff !important;\\n  border-bottom: 1px solid #eeeae0 !important;\\n  box-shadow: 0 1px 0 rgba(0,0,0,0.02);\\n  padding: 0.5rem 1.5rem !important;\\n  min-height: 64px;\\n}\\n.navbar-end .navbar-item { color: #2d2d2d !important; font-weight: 500; }\\n\\n.sv-brand-text {\\n  font-family: 'Rubik', sans-serif !important;\\n  font-weight: 700 !important;\\n  letter-spacing: 0.5px !important;\\n  text-transform: uppercase !important;\\n  font-size: 16px !important;\\n  line-height: 32px !important;\\n  color: #0a0a0a !important;\\n}\\n\\n/* ============ SIDEBAR / MENU ============ */\\naside.menu, .menu {\\n  background-color: transparent !important;\\n  padding: 1rem 0.75rem !important;\\n}\\naside.menu .menu-list a, .menu-list a {\\n  border-radius: 12px !important;\\n  padding: 12px 16px !important;\\n  color: #2d2d2d !important;\\n  font-weight: 500 !important;\\n  margin-bottom: 4px !important;\\n  border-left: none !important;\\n  transition: background 0.15s ease, color 0.15s ease !important;\\n}\\naside.menu .menu-list a:hover, .menu-list a:hover {\\n  background-color: rgba(0,0,0,0.03) !important;\\n  color: #0a0a0a !important;\\n}\\naside.menu .menu-list a.is-active, .menu-list a.is-active,\\naside.menu li a.is-active {\\n  background-color: #ffd600 !important;\\n  color: #0a0a0a !important;\\n  font-weight: 700 !important;\\n  border-left: none !important;\\n  box-shadow: 0 2px 6px rgba(255, 214, 0, 0.3);\\n}\\n.menu-label { color: #777 !important; font-size: 11px !important; letter-spacing: 1px !important; text-transform: uppercase !important; padding: 0 16px !important; }\\n\\n/* ============ CARDS / BOXES / TILES ============ */\\n.box, .card, .modal-card, .b-table, .notification {\\n  background-color: #ffffff !important;\\n  border-radius: 16px !important;\\n  border: 1px solid #eeeae0 !important;\\n  box-shadow: 0 1px 3px rgba(0,0,0,0.04), 0 4px 12px rgba(0,0,0,0.04) !important;\\n  padding: 1.25rem 1.5rem !important;\\n}\\n.card-header { border-bottom: 1px solid #eeeae0 !important; box-shadow: none !important; }\\n.card-content { padding: 1.5rem !important; }\\n\\n/* Dashboard stat tiles */\\n.dashboard .box, .dashboard .card { padding: 1.5rem !important; }\\n.dashboard .has-text-weight-bold, .dashboard .is-size-1, .dashboard .is-size-2 {\\n  font-weight: 800 !important;\\n  color: #0a0a0a !important;\\n  letter-spacing: -1px !important;\\n}\\n\\n/* ============ BUTTONS ============ */\\n.button {\\n  border-radius: 999px !important;\\n  font-weight: 600 !important;\\n  padding: 0.6em 1.5em !important;\\n  height: auto !important;\\n  transition: all 0.15s ease !important;\\n  border-width: 1px !important;\\n}\\n.button.is-small { padding: 0.4em 1em !important; font-size: 12px !important; }\\n.button.is-medium { padding: 0.7em 1.8em !important; }\\n\\n.button.is-primary {\\n  background-color: #ffd600 !important;\\n  color: #0a0a0a !important;\\n  border-color: #ffd600 !important;\\n}\\n.button.is-primary:hover, .button.is-primary:focus {\\n  background-color: #e6c200 !important;\\n  border-color: #e6c200 !important;\\n  color: #0a0a0a !important;\\n  transform: translateY(-1px);\\n  box-shadow: 0 4px 12px rgba(255, 214, 0, 0.4);\\n}\\n\\n.button.is-link, .button.is-info {\\n  background-color: #0a0a0a !important;\\n  color: #fff !important;\\n  border-color: #0a0a0a !important;\\n}\\n.button.is-link:hover, .button.is-info:hover {\\n  background-color: #ffd600 !important; border-color: #ffd600 !important; color: #0a0a0a !important;\\n}\\n\\n.button.is-outlined, .button:not(.is-primary):not(.is-link):not(.is-info):not(.is-danger):not(.is-success) {\\n  border-color: #eeeae0 !important;\\n  background-color: #ffffff !important;\\n  color: #2d2d2d !important;\\n}\\n.button.is-outlined:hover, .button:not(.is-primary):not(.is-link):not(.is-info):not(.is-danger):not(.is-success):hover {\\n  border-color: #0a0a0a !important;\\n  color: #0a0a0a !important;\\n  background-color: #ffffff !important;\\n}\\n\\n.button.is-danger {\\n  background-color: #fff !important;\\n  color: #d32f2f !important;\\n  border-color: #fbd9d9 !important;\\n}\\n.button.is-danger:hover { background-color: #d32f2f !important; color: #fff !important; }\\n\\n/* ============ INPUTS ============ */\\n.input, .textarea, .select select {\\n  border-radius: 12px !important;\\n  border: 1px solid #eeeae0 !important;\\n  padding: 0.6em 0.9em !important;\\n  height: auto !important;\\n  background-color: #ffffff !important;\\n  font-family: inherit !important;\\n  font-size: 14px !important;\\n  box-shadow: none !important;\\n  transition: border-color 0.15s ease, box-shadow 0.15s ease !important;\\n}\\n.input:focus, .textarea:focus, .select select:focus {\\n  border-color: #ffd600 !important;\\n  box-shadow: 0 0 0 3px rgba(255, 214, 0, 0.18) !important;\\n  outline: none !important;\\n}\\n.label { font-weight: 600 !important; color: #2d2d2d !important; font-size: 13px !important; }\\n\\n/* ============ TAGS / BADGES ============ */\\n.tag {\\n  border-radius: 999px !important;\\n  font-weight: 600 !important;\\n  padding: 0.3em 0.9em !important;\\n  font-size: 11px !important;\\n  letter-spacing: 0.3px !important;\\n}\\n.tag.is-primary, .tag.is-link { background-color: #ffd600 !important; color: #0a0a0a !important; }\\n.tag.is-info { background-color: #fffbe6 !important; color: #0a0a0a !important; border: 1px solid #ffd600 !important; }\\n.tag.is-success { background-color: #e6f7ed !important; color: #1b7a3e !important; }\\n.tag.is-warning { background-color: #fff4e0 !important; color: #b06a00 !important; }\\n.tag.is-danger { background-color: #fdecec !important; color: #b22020 !important; }\\n\\n/* ============ TABLES ============ */\\n.b-table .table {\\n  background-color: transparent !important;\\n  border: none !important;\\n}\\n.table thead th {\\n  font-weight: 700 !important;\\n  color: #777 !important;\\n  text-transform: uppercase !important;\\n  font-size: 11px !important;\\n  letter-spacing: 0.5px !important;\\n  border-bottom: 2px solid #eeeae0 !important;\\n  background: transparent !important;\\n  padding: 12px 16px !important;\\n}\\n.table tbody td {\\n  border-bottom: 1px solid #eeeae0 !important;\\n  padding: 14px 16px !important;\\n  vertical-align: middle !important;\\n}\\n.table tbody tr:hover { background-color: rgba(255, 214, 0, 0.04) !important; }\\n\\n/* ============ TABS ============ */\\n.tabs ul { border-bottom: 1px solid #eeeae0 !important; }\\n.tabs li a {\\n  border-bottom-width: 2px !important;\\n  color: #777 !important;\\n  font-weight: 500 !important;\\n  padding: 0.75em 1em !important;\\n}\\n.tabs li.is-active a {\\n  border-bottom-color: #ffd600 !important;\\n  color: #0a0a0a !important;\\n  font-weight: 700 !important;\\n}\\n\\n/* ============ NOTIFICATIONS ============ */\\n.notification { border-left: 4px solid #ffd600 !important; padding: 1rem 1.25rem !important; }\\n.notification.is-primary { background-color: #fffbe6 !important; color: #0a0a0a !important; }\\n.notification.is-link, .notification.is-info { background-color: #fffbe6 !important; color: #0a0a0a !important; }\\n\\n/* ============ PROGRESS / LOADING ============ */\\nprogress {\\n  border-radius: 999px !important;\\n  height: 6px !important;\\n  background-color: #f0ece2 !important;\\n}\\nprogress::-webkit-progress-value { background-color: #ffd600 !important; border-radius: 999px !important; }\\nprogress::-moz-progress-bar { background-color: #ffd600 !important; }\\n.b-loading-icon::after { border-color: #ffd600 transparent #ffd600 transparent !important; }\\n[id*=\\"nprogress\\"] .bar { background: #ffd600 !important; }\\n\\n/* ============ MODALS ============ */\\n.modal-card { border-radius: 16px !important; overflow: hidden; }\\n.modal-card-head, .modal-card-foot { background-color: #ffffff !important; border-color: #eeeae0 !important; }\\n\\n/* ============ DROPDOWNS ============ */\\n.dropdown-content { border-radius: 12px !important; box-shadow: 0 1px 3px rgba(0,0,0,0.04), 0 4px 12px rgba(0,0,0,0.04) !important; border: 1px solid #eeeae0 !important; }\\n.dropdown-item { padding: 0.6em 1em !important; font-weight: 500 !important; }\\n.dropdown-item:hover { background-color: #fffbe6 !important; color: #0a0a0a !important; }\\n\\n/* ============ SWITCHES ============ */\\n.switch input[type=\\"checkbox\\"]:checked + .check {\\n  background-color: #ffd600 !important;\\n}\\n\\n/* ============ LINKS ============ */\\na, a:visited { color: #2d2d2d; }\\na:hover { color: #0a0a0a; }\\n\\n/* ============ HELPER OVERRIDES ============ */\\n.has-text-link, .has-text-info, .has-text-primary { color: #0a0a0a !important; }\\n.has-background-link, .has-background-info, .has-background-primary {\\n  background-color: #ffd600 !important; color: #0a0a0a !important;\\n}\\n\\n/* ============ HIDE LISTMONK BRANDING ============ */\\n.navbar-brand a[href*=\\"listmonk.app\\"] { display: none !important; }\\n\\n/* Subtle separators where needed */\\nhr { background-color: #eeeae0 !important; height: 1px !important; }\\n\\n\\n/* Sub-menu active items — softer transparent yellow vs solid for parent */\\naside.menu .menu-list ul a.is-active,\\n.menu-list ul a.is-active,\\n.menu-list li ul li a.is-active {\\n  background-color: rgba(255, 214, 0, 0.22) !important;\\n  color: #0a0a0a !important;\\n  font-weight: 600 !important;\\n  box-shadow: none !important;\\n}\\naside.menu .menu-list ul a:hover,\\n.menu-list ul a:hover {\\n  background-color: rgba(255, 214, 0, 0.10) !important;\\n}\\n/* Sub-menu items — slightly indented for hierarchy */\\n.menu-list ul { margin-left: 0 !important; padding-left: 0 !important; border-left: 1px solid #eeeae0 !important; margin-top: 4px !important; }\\n.menu-list ul a { padding-left: 24px !important; }\\n\\n\\n/* === COMPACT DASHBOARD === */\\n/* Reduce padding inside Listmonk's default dashboard tiles + cards */\\nsection.section { padding: 24px !important; }\\nsection.section .container { padding: 0 !important; }\\n\\n.box, .card, .notification {\\n  padding: 14px 18px !important;\\n  border-radius: 12px !important;\\n}\\n.dashboard .box, .dashboard .card { padding: 16px 18px !important; }\\n\\n/* Tighten dashboard tile typography */\\n.dashboard .has-text-weight-bold,\\n.dashboard .is-size-1,\\n.dashboard .is-size-2,\\n.dashboard .is-size-3 {\\n  font-size: 24px !important;\\n  letter-spacing: -0.5px !important;\\n  line-height: 1.1 !important;\\n}\\n.dashboard .is-size-4, .dashboard .is-size-5 { font-size: 16px !important; line-height: 1.2 !important; }\\n\\n/* Smaller chart heights so they don't dominate */\\ncanvas, .chart-container { max-height: 220px !important; }\\n\\n/* Tighter row gaps in dashboard grids */\\n.tile.is-ancestor, .columns { margin-bottom: 12px !important; }\\n.tile.is-parent { padding: 6px !important; }\\n.column { padding: 6px !important; }\\n\\n/* Smaller titles */\\n.title.is-1, h1.title { font-size: 24px !important; margin-bottom: 12px !important; }\\n.title.is-2 { font-size: 20px !important; }\\n.title.is-4 { font-size: 15px !important; }\\n\\n/* Tighter widget padding */\\n#sv-widgets { gap: 12px !important; margin-top: 16px !important; }\\n#sv-widgets .sv-widget { padding: 14px 16px !important; }\\n#sv-widgets .sv-widget h3 { font-size: 11px !important; margin-bottom: 10px !important; }\\n\\n/* Allow more widgets per row by lowering min column width */\\n#sv-widgets {\\n  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)) !important;\\n}\\n\\n\\n/* ===== Pre-hide Listmonk's default dashboard on /admin/ to prevent flash ===== */\\n/* These selectors target the built-in dashboard component. When the user is NOT on */\\n/* the dashboard, these elements don't render so the rules are harmless no-ops. */\\n.dashboard,\\nsection.section > .tile.is-ancestor,\\nsection.section > .tile.is-ancestor ~ .columns,\\nsection.section > .box {\\n  opacity: 0 !important;\\n  transition: none !important;\\n}\\n/* Our custom wrap always stays fully visible */\\n#sv-dashboard, #sv-dashboard * { opacity: 1 !important; }\\n"	2026-04-17 17:32:05.899219+00
privacy.individual_tracking	false	2026-04-17 17:32:05.899219+00
upload.s3.aws_access_key_id	""	2026-04-17 17:32:05.899219+00
upload.filesystem.upload_uri	"/uploads"	2026-04-17 17:32:05.899219+00
app.enable_public_subscription_page	true	2026-04-17 17:32:05.899219+00
app.message_sliding_window_duration	"1h"	2026-04-17 17:32:05.899219+00
appearance.public.custom_js	"\\n(function () {\\n  function init() {\\n    // Make Name field required\\n    var nameInput = document.getElementById('name');\\n    if (nameInput) {\\n      nameInput.required = true;\\n      nameInput.placeholder = 'Name';\\n      var label = document.querySelector('label[for=\\"name\\"]');\\n      if (label) label.textContent = 'Name';\\n    }\\n\\n    // Replace \\"Powered by listmonk\\" footer with Street Voices branding\\n    var footer = document.querySelector('footer.container');\\n    if (footer) {\\n      var year = new Date().getFullYear();\\n      footer.innerHTML =\\n        '<div style=\\"text-align:center;font-size:12px;color:#666;line-height:18px;\\">' +\\n          '&copy; ' + year + ' Street Voices &nbsp;&middot;&nbsp; ' +\\n          '<a href=\\"https://streetvoices.ca\\">streetvoices.ca</a> &nbsp;&middot;&nbsp; ' +\\n          '720 Bathurst Street, Toronto, ON M5S 2R4' +\\n        '</div>';\\n    }\\n  }\\n  if (document.readyState === 'loading') {\\n    document.addEventListener('DOMContentLoaded', init);\\n  } else {\\n    init();\\n  }\\n})();\\n"	2026-04-17 17:32:05.899219+00
appearance.public.custom_css	"\\n/* Street Voices public-page theming */\\n@import url('https://fonts.googleapis.com/css2?family=Rubik:wght@400;500;600;700;900&display=swap');\\n\\nbody {\\n  font-family: 'Rubik', 'Helvetica Neue', Arial, sans-serif !important;\\n  background: #f4f4f4 !important;\\n  color: #1a1a1a !important;\\n  margin: 0;\\n}\\n\\n.container.wrap {\\n  max-width: 600px !important;\\n  margin: 32px auto !important;\\n  background: #fff !important;\\n  border-radius: 8px !important;\\n  padding: 32px !important;\\n  box-shadow: 0 2px 12px rgba(0,0,0,0.04);\\n  border-top: 4px solid #ffd600;\\n}\\n\\n.header {\\n  text-align: center !important;\\n  border-bottom: 1px solid #ffd600;\\n  padding-bottom: 16px;\\n  margin-bottom: 24px;\\n}\\n.header .logo img,\\n.header .logo a img {\\n  width: 96px !important;\\n  height: 96px !important;\\n  border-radius: 50%;\\n}\\n\\nh1, h2, h3 {\\n  font-family: 'Rubik', 'Helvetica Neue', Arial, sans-serif !important;\\n  color: #000000 !important;\\n  font-weight: 900 !important;\\n  letter-spacing: 0.5px !important;\\n  text-transform: uppercase !important;\\n  margin: 24px 0 12px 0 !important;\\n}\\nh2 { font-size: 22px !important; line-height: 28px !important; }\\nh3 { font-size: 16px !important; line-height: 22px !important; }\\n\\np, li, label { font-size: 15px !important; line-height: 24px !important; }\\n\\na {\\n  color: #000000 !important;\\n  font-weight: 700 !important;\\n  text-decoration: underline !important;\\n  text-decoration-color: #ffd600 !important;\\n  text-decoration-thickness: 2px !important;\\n  text-underline-offset: 2px !important;\\n}\\na:hover { color: #e6c200 !important; }\\n\\ninput[type=\\"email\\"], input[type=\\"text\\"], input[type=\\"password\\"] {\\n  width: 100%;\\n  padding: 12px 14px !important;\\n  border: 1px solid #ddd !important;\\n  border-radius: 4px !important;\\n  font-family: inherit !important;\\n  font-size: 15px !important;\\n  box-sizing: border-box;\\n  margin-top: 4px;\\n}\\ninput:focus { outline: 2px solid #ffd600 !important; border-color: #ffd600 !important; }\\n\\nlabel { display: block; font-weight: 600; margin-top: 12px; }\\n\\nbutton, .button, button[type=\\"submit\\"] {\\n  background: #ffd600 !important;\\n  color: #000000 !important;\\n  font-family: 'Rubik', 'Helvetica Neue', Arial, sans-serif !important;\\n  font-weight: 700 !important;\\n  text-transform: uppercase !important;\\n  letter-spacing: 0.5px !important;\\n  border: 2px solid #ffd600 !important;\\n  border-radius: 30px !important;\\n  padding: 10px 25px !important;\\n  cursor: pointer !important;\\n  font-size: 14px !important;\\n  text-decoration: none !important;\\n}\\nbutton:hover, .button:hover { background: #e6c200 !important; border-color: #e6c200 !important; }\\n\\nul.lists { list-style: none; padding: 0; margin: 16px 0; }\\nul.lists li {\\n  padding: 12px;\\n  border: 1px solid #eee;\\n  border-radius: 4px;\\n  margin-bottom: 8px;\\n  background: #fafafa;\\n}\\nul.lists li input[type=\\"checkbox\\"] { margin-right: 8px; }\\nul.lists li label { display: inline; font-weight: 700; text-transform: uppercase; }\\nul.lists .description { font-size: 13px; color: #555; margin-top: 4px; font-weight: 400; text-transform: none; }\\n\\n.right a { font-size: 13px; }\\n\\nfooter, .footer {\\n  margin-top: 24px;\\n  padding-top: 16px;\\n  border-top: 1px solid #ffd600;\\n  text-align: center;\\n  font-size: 12px;\\n  color: #888;\\n}\\n"	2026-04-17 17:32:05.899219+00
upload.s3.aws_default_region	"ap-south-1"	2026-04-17 17:32:05.899219+00
upload.filesystem.upload_path	"uploads"	2026-04-17 17:32:05.899219+00
app.enable_public_archive_rss_content	true	2026-04-17 17:32:05.899219+00
\.


--
-- Data for Name: subscriber_lists; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscriber_lists (subscriber_id, list_id, meta, status, created_at, updated_at) FROM stdin;
34	40	{}	confirmed	2026-04-20 04:21:40.181714+00	2026-04-20 04:21:40.181714+00
34	35	{}	confirmed	2026-04-20 04:21:40.181714+00	2026-04-20 04:21:40.181714+00
35	35	{}	confirmed	2026-04-20 15:58:47.044778+00	2026-04-20 15:59:43.951545+00
35	36	{}	confirmed	2026-04-20 15:58:47.044778+00	2026-04-20 15:59:43.951545+00
36	35	{}	confirmed	2026-04-22 02:47:58.726889+00	2026-04-22 02:47:58.726889+00
36	36	{}	confirmed	2026-04-22 02:47:58.726889+00	2026-04-22 02:47:58.726889+00
\.


--
-- Data for Name: subscribers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscribers (id, uuid, email, name, attribs, status, created_at, updated_at) FROM stdin;
34	3a4e92e0-35fe-4f35-a49c-309302202aef	daniela.mattachang@torontomu.ca	Daniela Matta	{"city": "Toronto", "source": "internal_seed", "language": "en", "interests": ["internal", "qa"], "joined_at": "2026-04-20", "last_name": "Matta", "donor_tier": null, "first_name": "Daniela", "welcomed_at": "2026-04-21T01:03:25.431Z", "lifecycle_stage": "active"}	enabled	2026-04-17 20:26:58.998174+00	2026-04-21 01:03:25.468583+00
35	59919db0-c4dd-4ef9-a832-decd9e16059a	dany19star@gmail.com	Anne Peggy	{"welcomed_at": "2026-04-21T01:51:48.904Z"}	enabled	2026-04-20 15:58:47.044778+00	2026-04-21 01:51:48.910742+00
36	3d0aeb29-280a-4810-9448-ff9c9db5ccb6	dany.mattach@gmail.com	Sergio Rodriguez	{"welcomed_at": "2026-04-22T02:48:00.789Z"}	enabled	2026-04-22 02:47:58.726889+00	2026-04-22 02:48:00.794005+00
\.


--
-- Data for Name: templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.templates (id, name, type, subject, body, body_source, is_default, created_at, updated_at) FROM stdin;
1	Default campaign template	campaign		<!doctype html>\n<html>\n    <head>\n        <title>{{ .Campaign.Subject }}</title>\n        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">\n        <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">\n        <base target="_blank">\n        <style>\n            body {\n                background-color: #F0F1F3;\n                font-family: 'Helvetica Neue', 'Segoe UI', Helvetica, sans-serif;\n                font-size: 15px;\n                line-height: 26px;\n                margin: 0;\n                color: #444;\n            }\n\n            pre {\n                background: #f4f4f4f4;\n                padding: 2px;\n            }\n\n            table {\n                width: 100%;\n                border: 1px solid #ddd;\n            }\n            table td {\n                border-color: #ddd;\n                padding: 5px;\n            }\n\n            .wrap {\n                background-color: #fff;\n                padding: 30px;\n                max-width: 525px;\n                margin: 0 auto;\n                border-radius: 5px;\n            }\n\n            .button {\n                background: #0055d4;\n                border-radius: 3px;\n                text-decoration: none !important;\n                color: #fff !important;\n                font-weight: bold;\n                padding: 10px 30px;\n                display: inline-block;\n            }\n            .button:hover {\n                background: #111;\n            }\n\n            .footer {\n                text-align: center;\n                font-size: 12px;\n                color: #888;\n            }\n                .footer a {\n                    color: #888;\n                    margin-right: 5px;\n                }\n\n            .gutter {\n                padding: 30px;\n            }\n\n            img {\n                max-width: 100%;\n                height: auto;\n            }\n\n            a {\n                color: #0055d4;\n            }\n                a:hover {\n                    color: #111;\n                }\n            @media screen and (max-width: 600px) {\n                .wrap {\n                    max-width: auto;\n                }\n                .gutter {\n                    padding: 10px;\n                }\n            }\n        </style>\n    </head>\n<body style="background-color: #F0F1F3;font-family: 'Helvetica Neue', 'Segoe UI', Helvetica, sans-serif;font-size: 15px;line-height: 26px;margin: 0;color: #444;">\n    <div class="gutter" style="padding: 30px;">&nbsp;</div>\n    <div class="wrap" style="background-color: #fff;padding: 30px;max-width: 525px;margin: 0 auto;border-radius: 5px;">\n        {{ template "content" . }}\n    </div>\n    \n    <div class="footer" style="text-align: center;font-size: 12px;color: #888;">\n        <p>\n            <a href="{{ UnsubscribeURL }}" style="color: #888;">{{ L.T "email.unsub" }}</a>\n            &nbsp;&nbsp;\n            <a href="{{ MessageURL }}" style="color: #888;">{{ L.T "email.viewInBrowser" }}</a>\n        </p>\n    </div>\n    <div class="gutter" style="padding: 30px;">&nbsp;{{ TrackView }}</div>\n</body>\n</html>\n	\N	f	2026-04-17 17:32:17.234669+00	2026-04-17 17:32:17.234669+00
34	Street Voices base	campaign	Street Voices base	<!doctype html>\n<html>\n<head>\n<title>{{ .Campaign.Subject }}</title>\n<meta http-equiv="Content-Type" content="text/html; charset=utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">\n<meta name="color-scheme" content="light only">\n<meta name="supported-color-schemes" content="light only">\n<base target="_blank">\n</head>\n<body style="margin:0;padding:0;background-color:#f4f4f4;font-family:'Helvetica Neue',Arial,Helvetica,sans-serif;color:#1a1a1a;-webkit-font-smoothing:antialiased;">\n<div style="display:none;max-height:0;overflow:hidden;">{{ .Campaign.Subject }} — Street Voices</div>\n\n<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color:#f4f4f4;">\n<tr><td align="center" style="padding:24px 12px;">\n\n  <table role="presentation" width="600" cellpadding="0" cellspacing="0" border="0" style="max-width:600px;width:100%;background-color:#ffffff;border-radius:8px;overflow:hidden;">\n\n    <tr><td align="center" style="padding:32px 24px 16px 24px;background-color:#ffffff;">\n      <img src="__SV_ROOT_URL__/uploads/Street-voices-logo.png?v=1776870148173" width="120" height="120" alt="Street Voices" style="display:block;width:120px;height:120px;border:0;outline:none;">\n    </td></tr>\n\n    <tr><td style="padding:0 24px;"><div style="height:4px;background-color:#ffd600;border-radius:2px;"></div></td></tr>\n\n    <tr><td style="padding:24px 32px 8px 32px;font-family:'Helvetica Neue',Arial,Helvetica,sans-serif;font-size:16px;line-height:26px;color:#1a1a1a;">\n      {{ template "content" . }}\n    </td></tr>\n\n    <tr><td style="padding:24px 32px 0 32px;"><div style="height:1px;background-color:#ffd600;"></div></td></tr>\n\n    <tr><td align="left" style="padding:24px 32px 8px 32px;font-family:'Helvetica Neue',Arial,Helvetica,sans-serif;font-size:11px;line-height:18px;color:#1a1a1a;">\n      <img src="__SV_ROOT_URL__/uploads/Street-voices-logo.png?v=1776870148173" width="72" height="72" alt="Street Voices" style="display:block;width:72px;height:72px;border:0;outline:none;margin-bottom:12px;">\n      <div style="font-weight:bold;letter-spacing:0.4px;text-transform:uppercase;color:#000000;">STREET VOICES&nbsp;&nbsp;<span style="color:#ffd600;">|</span>&nbsp;&nbsp;COMMUNICATIONS</div>\n      <div style="margin-top:3px;"><a href="https://streetvoices.ca" style="color:#000000;text-decoration:underline;font-weight:bold;text-transform:uppercase;">STREETVOICES.CA</a>&nbsp;&nbsp;<span style="color:#ffd600;font-weight:bold;">|</span>&nbsp;&nbsp;<span style="font-weight:bold;">(416) 697-6626</span></div>\n      <div style="margin-top:3px;font-weight:bold;text-transform:uppercase;">720 BATHURST STREET, TOR ON, M5S 2R4</div>\n    </td></tr>\n\n    <tr><td align="left" style="padding:12px 32px 24px 32px;"><table role="presentation" cellpadding="0" cellspacing="0" border="0"><tr>\n        <td style="padding-right:8px;">\n          <a href="https://www.facebook.com/StreetVoicesTO/" style="text-decoration:none;">\n            <table role="presentation" cellpadding="0" cellspacing="0" border="0"><tr>\n              <td align="center" valign="middle" width="36" height="36" style="width:36px;height:36px;background-color:#ffd600;border-radius:18px;text-align:center;vertical-align:middle;">\n                <img src="__SV_ROOT_URL__/uploads/facebook.png?v=1776870148173" width="22" height="22" alt="Facebook" style="display:block;width:22px;height:22px;border:0;outline:none;margin:0 auto;">\n              </td>\n            </tr></table>\n          </a>\n        </td>\n        <td style="padding-right:8px;">\n          <a href="https://x.com/StreetVoicesTO" style="text-decoration:none;">\n            <table role="presentation" cellpadding="0" cellspacing="0" border="0"><tr>\n              <td align="center" valign="middle" width="36" height="36" style="width:36px;height:36px;background-color:#ffd600;border-radius:18px;text-align:center;vertical-align:middle;">\n                <img src="__SV_ROOT_URL__/uploads/twitter.png?v=1776870148173" width="22" height="22" alt="X" style="display:block;width:22px;height:22px;border:0;outline:none;margin:0 auto;">\n              </td>\n            </tr></table>\n          </a>\n        </td>\n        <td>\n          <a href="https://www.instagram.com/streetvoicesto" style="text-decoration:none;">\n            <table role="presentation" cellpadding="0" cellspacing="0" border="0"><tr>\n              <td align="center" valign="middle" width="36" height="36" style="width:36px;height:36px;background-color:#ffd600;border-radius:18px;text-align:center;vertical-align:middle;">\n                <img src="__SV_ROOT_URL__/uploads/instagram.png?v=1776870148173" width="22" height="22" alt="Instagram" style="display:block;width:22px;height:22px;border:0;outline:none;margin:0 auto;">\n              </td>\n            </tr></table>\n          </a>\n        </td>\n      </tr></table>\n    </td></tr>\n\n    <tr><td style="padding:0 24px 24px 24px;"><div style="height:4px;background-color:#ffd600;border-radius:2px;"></div></td></tr>\n\n  </table>\n\n  <table role="presentation" width="600" cellpadding="0" cellspacing="0" border="0" style="max-width:600px;width:100%;">\n    <tr><td align="center" style="padding:16px 24px 8px 24px;font-family:'Helvetica Neue',Arial,Helvetica,sans-serif;font-size:11px;line-height:18px;color:#666666;">\n      You're receiving this email because you subscribed to updates from Street Voices.<br>\n      Sent to {{ .Subscriber.Email }} from Street Voices, 720 Bathurst Street, Tor ON, M5S 2R4, Canada.\n    </td></tr>\n    <tr><td align="center" style="padding:0 24px 24px 24px;font-family:'Helvetica Neue',Arial,Helvetica,sans-serif;font-size:12px;line-height:20px;color:#666666;">\n      <a href="{{ UnsubscribeURL }}" style="color:#000000;text-decoration:underline;font-weight:bold;">Unsubscribe</a>\n      &nbsp;<span style="color:#ffd600;">&middot;</span>&nbsp;\n      <a href="{{ ManageURL }}" style="color:#000000;text-decoration:underline;font-weight:bold;">Manage preferences</a>\n      &nbsp;<span style="color:#ffd600;">&middot;</span>&nbsp;\n      <a href="{{ MessageURL }}" style="color:#000000;text-decoration:underline;font-weight:bold;">View in browser</a>\n    </td></tr>\n  </table>\n\n</td></tr>\n</table>\n{{ TrackView }}\n</body>\n</html>	\N	t	2026-04-20 03:08:20.189154+00	2026-04-22 15:02:28.185076+00
35	Welcome	tx	Welcome to Street Voices{{ if .Subscriber.FirstName }}, {{ .Subscriber.FirstName }}{{ end }}!	<!doctype html>\n<html>\n<head>\n<title>Welcome to Street Voices</title>\n<meta http-equiv="Content-Type" content="text/html; charset=utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">\n<base target="_blank">\n</head>\n<body style="margin:0;padding:0;background-color:#f4f4f4;font-family:'Helvetica Neue',Arial,Helvetica,sans-serif;color:#1a1a1a;">\n<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color:#f4f4f4;">\n<tr><td align="center" style="padding:24px 12px;">\n\n  <table role="presentation" width="600" cellpadding="0" cellspacing="0" border="0" style="max-width:600px;width:100%;background-color:#ffffff;border-radius:8px;overflow:hidden;">\n\n    <tr><td align="center" style="padding:32px 24px 16px 24px;">\n      <img src="__SV_ROOT_URL__/uploads/Street-voices-logo.png?v=1776870148208" width="120" height="120" alt="Street Voices" style="display:block;width:120px;height:120px;border:0;outline:none;">\n    </td></tr>\n\n    <tr><td style="padding:0 24px;"><div style="height:4px;background-color:#ffd600;border-radius:2px;"></div></td></tr>\n\n    <tr><td style="padding:32px 32px 8px 32px;font-family:'Helvetica Neue',Arial,Helvetica,sans-serif;font-size:16px;line-height:26px;color:#1a1a1a;">\n      <h1 style="font-weight:900;font-size:28px;line-height:34px;color:#000000;margin:0 0 8px 0;text-transform:uppercase;letter-spacing:0.5px;">Welcome to Street Voices{{ if .Subscriber.FirstName }}, {{ .Subscriber.FirstName }}{{ end }}!</h1>\n      <p style="margin:0 0 16px 0;color:#666666;font-size:14px;letter-spacing:0.3px;text-transform:uppercase;font-weight:bold;">Thanks for joining the community</p>\n\n      <p>You're now signed up to hear from us. Here's what to expect:</p>\n      <ul style="padding-left:20px;">\n        <li><strong>Community stories</strong> — what's happening across our neighbourhoods</li>\n        <li><strong>Event announcements</strong> — workshops, gatherings, and openings</li>\n        <li><strong>Ways to get involved</strong> — volunteer opportunities, calls for participation</li>\n      </ul>\n      <p>We send updates regularly, never share your email, and you can unsubscribe anytime from any of our messages.</p>\n\n      <p style="margin-top:32px;">\n        <a href="https://streetvoices.ca" style="display:inline-block;background-color:#ffd600;color:#000000;text-decoration:none;font-weight:bold;padding:14px 28px;border-radius:4px;text-transform:uppercase;letter-spacing:0.5px;">Visit StreetVoices.ca</a>\n      </p>\n\n      <p style="margin-top:32px;color:#444;">In community,<br><strong>The Street Voices team</strong></p>\n    </td></tr>\n\n    <tr><td style="padding:24px 32px 0 32px;"><div style="height:1px;background-color:#ffd600;"></div></td></tr>\n\n    <tr><td align="left" style="padding:24px 32px 8px 32px;font-family:'Helvetica Neue',Arial,Helvetica,sans-serif;font-size:11px;line-height:18px;color:#1a1a1a;">\n      <img src="__SV_ROOT_URL__/uploads/Street-voices-logo.png?v=1776870148208" width="72" height="72" alt="Street Voices" style="display:block;width:72px;height:72px;border:0;outline:none;margin-bottom:12px;">\n      <div style="font-weight:bold;letter-spacing:0.4px;text-transform:uppercase;color:#000000;">STREET VOICES&nbsp;&nbsp;<span style="color:#ffd600;">|</span>&nbsp;&nbsp;COMMUNICATIONS</div>\n      <div style="margin-top:3px;"><a href="https://streetvoices.ca" style="color:#000000;text-decoration:underline;font-weight:bold;text-transform:uppercase;">STREETVOICES.CA</a>&nbsp;&nbsp;<span style="color:#ffd600;font-weight:bold;">|</span>&nbsp;&nbsp;<span style="font-weight:bold;">(416) 697-6626</span></div>\n      <div style="margin-top:3px;font-weight:bold;text-transform:uppercase;">720 BATHURST STREET, TOR ON, M5S 2R4</div>\n    </td></tr>\n\n    <tr><td align="left" style="padding:12px 32px 24px 32px;">\n      <table role="presentation" cellpadding="0" cellspacing="0" border="0"><tr>\n        <td style="padding-right:8px;">\n          <a href="https://www.facebook.com/StreetVoicesTO/" style="text-decoration:none;">\n            <table role="presentation" cellpadding="0" cellspacing="0" border="0"><tr>\n              <td align="center" valign="middle" width="36" height="36" style="width:36px;height:36px;background-color:#ffd600;border-radius:18px;text-align:center;vertical-align:middle;">\n                <img src="__SV_ROOT_URL__/uploads/facebook.png?v=1776870148208" width="22" height="22" alt="Facebook" style="display:block;width:22px;height:22px;border:0;outline:none;margin:0 auto;">\n              </td>\n            </tr></table>\n          </a>\n        </td>\n        <td style="padding-right:8px;">\n          <a href="https://x.com/StreetVoicesTO" style="text-decoration:none;">\n            <table role="presentation" cellpadding="0" cellspacing="0" border="0"><tr>\n              <td align="center" valign="middle" width="36" height="36" style="width:36px;height:36px;background-color:#ffd600;border-radius:18px;text-align:center;vertical-align:middle;">\n                <img src="__SV_ROOT_URL__/uploads/twitter.png?v=1776870148208" width="22" height="22" alt="X" style="display:block;width:22px;height:22px;border:0;outline:none;margin:0 auto;">\n              </td>\n            </tr></table>\n          </a>\n        </td>\n        <td>\n          <a href="https://www.instagram.com/streetvoicesto" style="text-decoration:none;">\n            <table role="presentation" cellpadding="0" cellspacing="0" border="0"><tr>\n              <td align="center" valign="middle" width="36" height="36" style="width:36px;height:36px;background-color:#ffd600;border-radius:18px;text-align:center;vertical-align:middle;">\n                <img src="__SV_ROOT_URL__/uploads/instagram.png?v=1776870148208" width="22" height="22" alt="Instagram" style="display:block;width:22px;height:22px;border:0;outline:none;margin:0 auto;">\n              </td>\n            </tr></table>\n          </a>\n        </td>\n      </tr></table>\n    </td></tr>\n\n    <tr><td style="padding:0 24px 24px 24px;"><div style="height:4px;background-color:#ffd600;border-radius:2px;"></div></td></tr>\n\n  </table>\n\n  <table role="presentation" width="600" cellpadding="0" cellspacing="0" border="0" style="max-width:600px;width:100%;">\n    <tr><td align="center" style="padding:16px 24px 24px 24px;font-family:'Helvetica Neue',Arial,Helvetica,sans-serif;font-size:11px;line-height:18px;color:#666666;">\n      Sent to {{ .Subscriber.Email }} by Street Voices, 720 Bathurst Street, Toronto, ON M5S 2R4, Canada.\n    </td></tr>\n  </table>\n\n</td></tr>\n</table>\n</body>\n</html>	\N	f	2026-04-20 04:31:24.427362+00	2026-04-22 15:02:28.215672+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, password_login, password, email, name, avatar, type, user_role_id, list_role_id, status, twofa_type, twofa_key, loggedin_at, created_at, updated_at) FROM stdin;
1	admin	t	$2a$06$K8B8.WezFBOIwCJA5TUQNOzMG.TGXZTeWNeCQh7.EOYf.XEYYfvZ.	admin@listmonk	admin	\N	user	1	\N	enabled	none	\N	2026-04-24 00:06:34.097127+00	2026-04-17 17:32:18.056621+00	2026-04-24 00:04:27.310071+00
34	itsmedanii	t	$2a$06$Q5z2DJjelKFMMh0KtBbmoOSmrWnT55gNskHll4kp1Qjv8/1avgiS.	daniela.mattachang@torontomu.ca	Daniela Matta	\N	user	1	\N	enabled	none	\N	2026-04-24 21:07:46.769173+00	2026-04-17 18:13:15.67002+00	2026-04-20 04:21:39.673935+00
\.


--
-- Name: bounces_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bounces_id_seq', 1, false);


--
-- Name: campaign_lists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.campaign_lists_id_seq', 61, true);


--
-- Name: campaign_views_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.campaign_views_id_seq', 24, true);


--
-- Name: campaigns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.campaigns_id_seq', 52, true);


--
-- Name: link_clicks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.link_clicks_id_seq', 1, false);


--
-- Name: links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.links_id_seq', 1, false);


--
-- Name: lists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.lists_id_seq', 40, true);


--
-- Name: media_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.media_id_seq', 8, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.roles_id_seq', 33, true);


--
-- Name: subscribers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.subscribers_id_seq', 36, true);


--
-- Name: templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.templates_id_seq', 35, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 34, true);


--
-- Name: bounces bounces_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bounces
    ADD CONSTRAINT bounces_pkey PRIMARY KEY (id);


--
-- Name: campaign_lists campaign_lists_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaign_lists
    ADD CONSTRAINT campaign_lists_pkey PRIMARY KEY (id);


--
-- Name: campaign_views campaign_views_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaign_views
    ADD CONSTRAINT campaign_views_pkey PRIMARY KEY (id);


--
-- Name: campaigns campaigns_archive_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaigns
    ADD CONSTRAINT campaigns_archive_slug_key UNIQUE (archive_slug);


--
-- Name: campaigns campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaigns
    ADD CONSTRAINT campaigns_pkey PRIMARY KEY (id);


--
-- Name: campaigns campaigns_uuid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaigns
    ADD CONSTRAINT campaigns_uuid_key UNIQUE (uuid);


--
-- Name: link_clicks link_clicks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.link_clicks
    ADD CONSTRAINT link_clicks_pkey PRIMARY KEY (id);


--
-- Name: links links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.links
    ADD CONSTRAINT links_pkey PRIMARY KEY (id);


--
-- Name: links links_url_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.links
    ADD CONSTRAINT links_url_key UNIQUE (url);


--
-- Name: links links_uuid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.links
    ADD CONSTRAINT links_uuid_key UNIQUE (uuid);


--
-- Name: lists lists_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lists
    ADD CONSTRAINT lists_pkey PRIMARY KEY (id);


--
-- Name: lists lists_uuid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lists
    ADD CONSTRAINT lists_uuid_key UNIQUE (uuid);


--
-- Name: media media_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT media_pkey PRIMARY KEY (id);


--
-- Name: media media_uuid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT media_uuid_key UNIQUE (uuid);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: settings settings_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_key_key UNIQUE (key);


--
-- Name: subscriber_lists subscriber_lists_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriber_lists
    ADD CONSTRAINT subscriber_lists_pkey PRIMARY KEY (subscriber_id, list_id);


--
-- Name: subscribers subscribers_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscribers
    ADD CONSTRAINT subscribers_email_key UNIQUE (email);


--
-- Name: subscribers subscribers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscribers
    ADD CONSTRAINT subscribers_pkey PRIMARY KEY (id);


--
-- Name: subscribers subscribers_uuid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscribers
    ADD CONSTRAINT subscribers_uuid_key UNIQUE (uuid);


--
-- Name: templates templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.templates
    ADD CONSTRAINT templates_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: campaign_lists_campaign_id_list_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX campaign_lists_campaign_id_list_id_idx ON public.campaign_lists USING btree (campaign_id, list_id);


--
-- Name: idx_bounces_camp_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bounces_camp_id ON public.bounces USING btree (campaign_id);


--
-- Name: idx_bounces_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bounces_date ON public.bounces USING btree (created_at);


--
-- Name: idx_bounces_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bounces_source ON public.bounces USING btree (source);


--
-- Name: idx_bounces_sub_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bounces_sub_id ON public.bounces USING btree (subscriber_id);


--
-- Name: idx_camp_lists_camp_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_camp_lists_camp_id ON public.campaign_lists USING btree (campaign_id);


--
-- Name: idx_camp_lists_list_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_camp_lists_list_id ON public.campaign_lists USING btree (list_id);


--
-- Name: idx_camp_media_camp_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_camp_media_camp_id ON public.campaign_media USING btree (campaign_id);


--
-- Name: idx_camp_media_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_camp_media_id ON public.campaign_media USING btree (campaign_id, media_id);


--
-- Name: idx_camps_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_camps_created_at ON public.campaigns USING btree (created_at);


--
-- Name: idx_camps_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_camps_name ON public.campaigns USING btree (name);


--
-- Name: idx_camps_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_camps_status ON public.campaigns USING btree (status);


--
-- Name: idx_camps_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_camps_updated_at ON public.campaigns USING btree (updated_at);


--
-- Name: idx_clicks_camp_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clicks_camp_id ON public.link_clicks USING btree (campaign_id);


--
-- Name: idx_clicks_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clicks_date ON public.link_clicks USING btree (created_at);


--
-- Name: idx_clicks_link_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clicks_link_id ON public.link_clicks USING btree (link_id);


--
-- Name: idx_clicks_sub_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clicks_sub_id ON public.link_clicks USING btree (subscriber_id);


--
-- Name: idx_lists_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lists_created_at ON public.lists USING btree (created_at);


--
-- Name: idx_lists_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lists_name ON public.lists USING btree (name);


--
-- Name: idx_lists_optin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lists_optin ON public.lists USING btree (optin);


--
-- Name: idx_lists_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lists_status ON public.lists USING btree (status);


--
-- Name: idx_lists_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lists_type ON public.lists USING btree (type);


--
-- Name: idx_lists_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lists_updated_at ON public.lists USING btree (updated_at);


--
-- Name: idx_media_filename; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_media_filename ON public.media USING btree (provider, filename);


--
-- Name: idx_roles; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_roles ON public.roles USING btree (parent_id, list_id);


--
-- Name: idx_roles_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_roles_name ON public.roles USING btree (type, name) WHERE (name IS NOT NULL);


--
-- Name: idx_sessions; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sessions ON public.sessions USING btree (id, created_at);


--
-- Name: idx_settings_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_settings_key ON public.settings USING btree (key);


--
-- Name: idx_sub_lists_list_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sub_lists_list_id ON public.subscriber_lists USING btree (list_id);


--
-- Name: idx_sub_lists_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sub_lists_status ON public.subscriber_lists USING btree (status);


--
-- Name: idx_sub_lists_sub_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sub_lists_sub_id ON public.subscriber_lists USING btree (subscriber_id);


--
-- Name: idx_subs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_subs_created_at ON public.subscribers USING btree (created_at);


--
-- Name: idx_subs_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_subs_email ON public.subscribers USING btree (lower(email));


--
-- Name: idx_subs_id_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_subs_id_status ON public.subscribers USING btree (id, status);


--
-- Name: idx_subs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_subs_status ON public.subscribers USING btree (status);


--
-- Name: idx_subs_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_subs_updated_at ON public.subscribers USING btree (updated_at);


--
-- Name: idx_views_camp_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_views_camp_id ON public.campaign_views USING btree (campaign_id);


--
-- Name: idx_views_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_views_date ON public.campaign_views USING btree (created_at);


--
-- Name: idx_views_subscriber_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_views_subscriber_id ON public.campaign_views USING btree (subscriber_id);


--
-- Name: mat_dashboard_charts_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mat_dashboard_charts_idx ON public.mat_dashboard_charts USING btree (updated_at);


--
-- Name: mat_dashboard_stats_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mat_dashboard_stats_idx ON public.mat_dashboard_counts USING btree (updated_at);


--
-- Name: mat_list_subscriber_stats_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mat_list_subscriber_stats_idx ON public.mat_list_subscriber_stats USING btree (list_id, status);


--
-- Name: templates_is_default_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX templates_is_default_idx ON public.templates USING btree (is_default) WHERE (is_default = true);


--
-- Name: bounces bounces_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bounces
    ADD CONSTRAINT bounces_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.campaigns(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bounces bounces_subscriber_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bounces
    ADD CONSTRAINT bounces_subscriber_id_fkey FOREIGN KEY (subscriber_id) REFERENCES public.subscribers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: campaign_lists campaign_lists_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaign_lists
    ADD CONSTRAINT campaign_lists_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.campaigns(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: campaign_lists campaign_lists_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaign_lists
    ADD CONSTRAINT campaign_lists_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: campaign_media campaign_media_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaign_media
    ADD CONSTRAINT campaign_media_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.campaigns(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: campaign_media campaign_media_media_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaign_media
    ADD CONSTRAINT campaign_media_media_id_fkey FOREIGN KEY (media_id) REFERENCES public.media(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: campaign_views campaign_views_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaign_views
    ADD CONSTRAINT campaign_views_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.campaigns(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: campaign_views campaign_views_subscriber_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaign_views
    ADD CONSTRAINT campaign_views_subscriber_id_fkey FOREIGN KEY (subscriber_id) REFERENCES public.subscribers(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: campaigns campaigns_archive_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaigns
    ADD CONSTRAINT campaigns_archive_template_id_fkey FOREIGN KEY (archive_template_id) REFERENCES public.templates(id) ON DELETE SET NULL;


--
-- Name: campaigns campaigns_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaigns
    ADD CONSTRAINT campaigns_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.templates(id) ON DELETE SET NULL;


--
-- Name: link_clicks link_clicks_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.link_clicks
    ADD CONSTRAINT link_clicks_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.campaigns(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: link_clicks link_clicks_link_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.link_clicks
    ADD CONSTRAINT link_clicks_link_id_fkey FOREIGN KEY (link_id) REFERENCES public.links(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: link_clicks link_clicks_subscriber_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.link_clicks
    ADD CONSTRAINT link_clicks_subscriber_id_fkey FOREIGN KEY (subscriber_id) REFERENCES public.subscribers(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: roles roles_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: roles roles_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: subscriber_lists subscriber_lists_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriber_lists
    ADD CONSTRAINT subscriber_lists_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: subscriber_lists subscriber_lists_subscriber_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriber_lists
    ADD CONSTRAINT subscriber_lists_subscriber_id_fkey FOREIGN KEY (subscriber_id) REFERENCES public.subscribers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: users users_list_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_list_role_id_fkey FOREIGN KEY (list_role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: users users_user_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_user_role_id_fkey FOREIGN KEY (user_role_id) REFERENCES public.roles(id) ON DELETE RESTRICT;


--
-- Name: mat_dashboard_charts; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.mat_dashboard_charts;


--
-- Name: mat_dashboard_counts; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.mat_dashboard_counts;


--
-- Name: mat_list_subscriber_stats; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.mat_list_subscriber_stats;


--
-- PostgreSQL database dump complete
--

\unrestrict ARBHrLAVVlabV5N1glwQYhN9JwacNLILnuWAjeb5CT0layuSBHNxPVGiFNlcHhE

